import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import AccessCode from './components/AccessCode';
import Dashboard from './components/Dashboard';
import EnrollForm from './components/EnrollForm';
import ConseillerInterface from './components/ConseillerInterface';
import StatsPage from './components/StatsPage';
import DispoPage from './components/DispoPage';
import ConvoPage from './components/ConvoPage';

function App() {
  const [hasAccess, setHasAccess] = React.useState(false);

  React.useEffect(() => {
    // Vérifier si l'accès a déjà été accordé dans cette session
    const accessGranted = sessionStorage.getItem('kom_access_granted');
    if (accessGranted === 'true') {
      setHasAccess(true);
    }
  }, []);

  const handleAccessGranted = () => {
    setHasAccess(true);
  };

  return (
    <Router>
      <Routes>
        {/* Routes protégées par mot de passe (plateforme de gestion) */}
        <Route 
          path="/" 
          element={
            hasAccess ? <Dashboard /> : <AccessCode onAccessGranted={handleAccessGranted} />
          } 
        />
        <Route 
          path="/dashboard" 
          element={
            hasAccess ? <Dashboard /> : <AccessCode onAccessGranted={handleAccessGranted} />
          } 
        />
        <Route 
          path="/enroll" 
          element={
            hasAccess ? <EnrollForm /> : <AccessCode onAccessGranted={handleAccessGranted} />
          } 
        />
        <Route 
          path="/stats" 
          element={
            hasAccess ? <StatsPage /> : <AccessCode onAccessGranted={handleAccessGranted} />
          } 
        />
        <Route 
          path="/dispo" 
          element={
            hasAccess ? <DispoPage /> : <AccessCode onAccessGranted={handleAccessGranted} />
          } 
        />
        <Route 
          path="/convo" 
          element={<ConvoPage />} 
        />
        
        {/* Interface conseiller - accès direct sans mot de passe */}
        <Route path="/:conseillerUrl" element={<ConseillerInterface />} />
        
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </Router>
  );
}

export default App;