import { createClient } from '@supabase/supabase-js';

// Check if Supabase is properly configured
const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

const isSupabaseConfigured = supabaseUrl && 
  supabaseAnonKey && 
  supabaseUrl !== 'your_supabase_project_url' && 
  supabaseAnonKey !== 'your_supabase_anon_key' &&
  supabaseUrl.startsWith('https://') && 
  supabaseUrl.includes('.supabase.co');

if (!isSupabaseConfigured) {
  console.error('Supabase environment variables are not configured. Please set up your .env file with valid Supabase credentials.');
}

// Use fallback values for initialization to prevent errors
const fallbackUrl = 'https://placeholder.supabase.co';
const fallbackKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InBsYWNlaG9sZGVyIiwicm9sZSI6ImFub24iLCJpYXQiOjE2NDUxMjM0NTYsImV4cCI6MTk2MDY5OTQ1Nn0.placeholder';

export const supabase = createClient(
  supabaseUrl || fallbackUrl,
  supabaseAnonKey || fallbackKey
);

// Helper functions
export const getConseillers = async () => {
  if (!isSupabaseConfigured) {
    throw new Error('Supabase n\'est pas configuré. Veuillez cliquer sur "Connect to Supabase" pour configurer votre base de données.');
  }
  
  const { data, error } = await supabase
    .from('conseillers')
    .select(`
      *,
      transferts (*)
    `)
    .order('created_at', { ascending: false });
  
  if (error) throw error;
  return data;
};

export const getConseillerByUrl = async (url: string) => {
  if (!isSupabaseConfigured) {
    throw new Error('Supabase n\'est pas configuré. Veuillez configurer votre base de données.');
  }
  
  const { data, error } = await supabase
    .from('conseillers')
    .select(`
      *,
      transferts (*)
    `)
    .eq('url_unique', url)
    .single();
  
  if (error) throw error;
  return data;
};

export const updateConseillerStatut = async (id: string, statut: string) => {
  if (!isSupabaseConfigured) {
    throw new Error('Supabase n\'est pas configuré.');
  }
  
  console.log('📝 Mise à jour du statut en base:', { id, statut });
  
  const { data, error } = await supabase
    .from('conseillers')
    .update({ statut })
    .eq('id', id)
    .select()
    .single();
  
  if (error) {
    console.error('❌ Erreur Supabase:', error);
    throw error;
  }
  
  console.log('✅ Statut mis à jour en base:', data);
  return data;
};

export const addTransfert = async (transfert: Omit<import('../types').Transfert, 'id' | 'created_at'>) => {
  if (!isSupabaseConfigured) {
    throw new Error('Supabase n\'est pas configuré.');
  }
  
  const now = new Date();
  const { error } = await supabase
    .from('transferts')
    .insert({
      ...transfert,
      date_transfert: now.toISOString().split('T')[0],
      heure_transfert: now.toTimeString().split(' ')[0],
    });
  
  if (error) throw error;
};

export const getTransfertsStats = (transferts: any[]) => {
  // Date réelle : 20 août 2025
  const now = new Date(2025, 7, 20); // Mois 7 = août (0-indexé)
  const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
  const todayString = now.toISOString().split('T')[0]; // 2025-08-20
  
  // Début de la semaine (lundi)
  const startOfWeek = new Date(today);
  const dayOfWeek = today.getDay();
  const daysToMonday = dayOfWeek === 0 ? 6 : dayOfWeek - 1; // Dimanche = 0, donc 6 jours en arrière
  startOfWeek.setDate(today.getDate() - daysToMonday);
  
  // Début du mois
  const startOfMonth = new Date(today.getFullYear(), today.getMonth(), 1);
  
  console.log('📊 Calcul des stats:', {
    today: todayString, // 2025-08-20
    startOfWeek: startOfWeek.toISOString().split('T')[0],
    startOfMonth: startOfMonth.toISOString().split('T')[0],
    totalTransferts: transferts.length
  });
  
  return {
    transferts_realises: transferts.length,
    transferts_aujourd_hui: transferts.filter(t => {
      const transfertDate = t.date_transfert;
      return transfertDate === todayString;
    }).length,
    transferts_semaine: transferts.filter(t => {
      const transfertDate = new Date(t.date_transfert + 'T00:00:00');
      return transfertDate >= startOfWeek;
    }).length,
    transferts_mois: transferts.filter(t => {
      const transfertDate = new Date(t.date_transfert + 'T00:00:00');
      return transfertDate >= startOfMonth;
    }).length,
  };
};

export const deleteConseiller = async (id: string) => {
  if (!isSupabaseConfigured) {
    throw new Error('Supabase n\'est pas configuré.');
  }
  
  const { error } = await supabase
    .from('conseillers')
    .delete()
    .eq('id', id);
  
  if (error) throw error;
};

export const updateConseillerEmail = async (id: string, newEmail: string) => {
  if (!isSupabaseConfigured) {
    throw new Error('Supabase n\'est pas configuré.');
  }
  
  console.log('📧 Mise à jour de l\'email en base:', { id, newEmail });
  
  const { data, error } = await supabase
    .from('conseillers')
    .update({ email: newEmail })
    .eq('id', id)
    .select()
    .single();
  
  if (error) {
    console.error('❌ Erreur Supabase lors de la mise à jour de l\'email:', error);
    throw error;
  }
  
  console.log('✅ Email mis à jour en base:', data);
  return data;
};

// Nouvelles fonctions pour le tracking des statuts
export const getStatusHistory = async (conseillerId?: string, dateDebut?: string, dateFin?: string) => {
  if (!isSupabaseConfigured) {
    throw new Error('Supabase n\'est pas configuré.');
  }
  
  let query = supabase
    .from('status_history')
    .select(`
      *,
      conseillers (nom, prenom)
    `)
    .order('timestamp_debut', { ascending: false });
  
  if (conseillerId) {
    query = query.eq('conseiller_id', conseillerId);
  }
  
  if (dateDebut) {
    query = query.gte('timestamp_debut', dateDebut);
  }
  
  if (dateFin) {
    // Ajouter 24h à la date de fin pour inclure toute la journée
    const dateFin24h = new Date(dateFin);
    dateFin24h.setDate(dateFin24h.getDate() + 1);
    query = query.lt('timestamp_debut', dateFin24h.toISOString());
  }
  
  const { data, error } = await query;
  if (error) throw error;
  return data;
};

export const calculateRealAvailabilityStats = async (
  conseillerIds: string[], 
  dateDebut: string, 
  dateFin: string
) => {
  if (!isSupabaseConfigured) {
    throw new Error('Supabase n\'est pas configuré.');
  }
  
  const stats = [];
  
  for (const conseillerId of conseillerIds) {
    // Récupérer l'historique pour ce conseiller dans la période
    const history = await getStatusHistory(conseillerId, dateDebut, dateFin);
    
    // Calculer les durées pour chaque statut
    const durees = {
      disponible: 0,
      indisponible: 0,
      avec_client: 0
    };
    
    const startPeriod = new Date(dateDebut + 'T09:00:00');
    const endPeriod = new Date(dateFin + 'T20:00:00');
    
    // Traiter chaque entrée d'historique
    for (const entry of history) {
      const entryStart = new Date(entry.timestamp_debut);
      const entryEnd = entry.timestamp_fin ? new Date(entry.timestamp_fin) : new Date();
      
      // Limiter aux bornes de la période demandée
      const periodeDebut = new Date(dateDebut);
      const periodeFin = new Date(dateFin);
      
      const debutEffectif = entryStart > periodeDebut ? entryStart : periodeDebut;
      const finEffective = entryEnd < periodeFin ? entryEnd : periodeFin;
      
      if (debutEffectif < finEffective) {
        const dureeMinutes = (finEffective.getTime() - debutEffectif.getTime()) / (1000 * 60);
        const dureeHeures = dureeMinutes / 60;
        
        // Ajouter aux bonnes catégories
        switch (entry.nouveau_statut) {
          case 'disponible':
            durees.disponible += dureeHeures;
            break;
          case 'indisponible':
            durees.indisponible += dureeHeures;
            break;
          case 'avec_client':
            durees.avec_client += dureeHeures;
            break;
        }
      }
    }
    
    const totalHeures = durees.disponible + durees.indisponible + durees.avec_client;
    
    stats.push({
      conseiller_id: conseillerId,
      heures_disponible: Math.round(durees.disponible * 100) / 100,
      heures_indisponible: Math.round(durees.indisponible * 100) / 100,
      heures_avec_client: Math.round(durees.avec_client * 100) / 100,
      total_heures: Math.round(totalHeures * 100) / 100,
      pourcentage_disponible: totalHeures > 0 ? Math.round((durees.disponible / totalHeures) * 100) : 0,
      pourcentage_indisponible: totalHeures > 0 ? Math.round((durees.indisponible / totalHeures) * 100) : 0,
      pourcentage_avec_client: totalHeures > 0 ? Math.round((durees.avec_client / totalHeures) * 100) : 0,
    });
  }
  
  return stats;
};

export const deleteTransfert = async (id: string) => {
  if (!isSupabaseConfigured) {
    throw new Error('Supabase n\'est pas configuré.');
  }
  
  const { error } = await supabase
    .from('transferts')
    .delete()
    .eq('id', id);
  
  if (error) throw error;
};