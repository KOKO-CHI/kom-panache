import React, { useState, useEffect } from 'react';
import { supabase, getConseillers, getTransfertsStats, addTransfert } from '../lib/supabase';
import { deleteConseiller } from '../lib/supabase';
import { Conseiller, ConseillerStats, Transfert } from '../types';
import { Users, Search, Filter, TrendingUp, Clock, User, Phone, Mail, MessageSquare, Target, UserPlus, Plus, CheckCircle, X, RefreshCw, Trash2, AlertTriangle, Moon, Sun } from 'lucide-react';
import Layout from './Layout';
import { Link } from 'react-router-dom';

interface ConseillerWithStats extends Conseiller {
  stats: ConseillerStats;
}

interface TransfertWithConseiller extends Transfert {
  conseiller: {
    nom: string;
    prenom: string;
  };
}

export default function Dashboard() {
  const [conseillers, setConseillers] = useState<ConseillerWithStats[]>([]);
  const [filteredConseillers, setFilteredConseillers] = useState<ConseillerWithStats[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [statutFilter, setStatutFilter] = useState('');
  const [assuranceFilter, setAssuranceFilter] = useState('');
  const [showTransfertModal, setShowTransfertModal] = useState(false);
  const [selectedConseiller, setSelectedConseiller] = useState<ConseillerWithStats | null>(null);
  const [transfertData, setTransfertData] = useState({
    nom_client: '',
    code_telephoniste: ''
  });
  const [isSubmittingTransfert, setIsSubmittingTransfert] = useState(false);
  const [transfertSuccess, setTransfertSuccess] = useState<string | null>(null);
  const [showDetailsModal, setShowDetailsModal] = useState(false);
  const [selectedConseillerDetails, setSelectedConseillerDetails] = useState<ConseillerWithStats | null>(null);
  const [showTransfertsModal, setShowTransfertsModal] = useState(false);
  const [transfertsModalData, setTransfertsModalData] = useState<{
    title: string;
    transferts: TransfertWithConseiller[];
  }>({ title: '', transferts: [] });
  const [transfertFilters, setTransfertFilters] = useState({
    conseiller: '',
    code: '',
    search: ''
  });
  const [lastUpdate, setLastUpdate] = useState<Date>(new Date());
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [conseillerToDelete, setConseillerToDelete] = useState<ConseillerWithStats | null>(null);
  const [isDeleting, setIsDeleting] = useState(false);
  const [deleteConfirmText, setDeleteConfirmText] = useState('');
  const [darkMode, setDarkMode] = useState(false);

  useEffect(() => {
    // Charger la préférence dark mode depuis localStorage
    const savedDarkMode = localStorage.getItem('dashboard_dark_mode');
    if (savedDarkMode) {
      setDarkMode(JSON.parse(savedDarkMode));
    }
    
    loadConseillers();
  }, []);

  const toggleDarkMode = () => {
    const newDarkMode = !darkMode;
    setDarkMode(newDarkMode);
    localStorage.setItem('dashboard_dark_mode', JSON.stringify(newDarkMode));
  };

  useEffect(() => {
    // Actualisation automatique toutes les 2 secondes
    const autoRefreshInterval = setInterval(() => {
      loadConseillers(true); // true = actualisation silencieuse
    }, 2000);

    return () => clearInterval(autoRefreshInterval);
  }, []);

  useEffect(() => {
    // Configuration du canal en temps réel avec un nom unique
    const channelName = `dashboard_updates_${Date.now()}`;
    const channel = supabase
      .channel(channelName)
      .on(
        'postgres_changes',
        { 
          event: '*', 
          schema: 'public', 
          table: 'conseillers' 
        },
        (payload) => {
          console.log('🔄 Conseiller mis à jour:', payload);
          // Forcer le rechargement des données
          setTimeout(() => {
            loadConseillers();
          }, 100);
        }
      )
      .on(
        'postgres_changes',
        { 
          event: '*', 
          schema: 'public', 
          table: 'transferts' 
        },
        (payload) => {
          console.log('🔄 Transfert mis à jour:', payload);
          // Forcer le rechargement des données
          setTimeout(() => {
            loadConseillers();
          }, 100);
        }
      )
      .subscribe((status) => {
        console.log('📡 Statut de souscription:', status);
      });

    return () => {
      console.log('🔌 Déconnexion du canal temps réel');
      channel.unsubscribe();
    };
  }, []);

  useEffect(() => {
    filterConseillers();
  }, [conseillers, searchTerm, statutFilter, assuranceFilter]);

  const loadConseillers = async (silent = false) => {
    try {
      // Ne pas montrer le loading si c'est une actualisation silencieuse ou une mise à jour en temps réel
      if (!silent && conseillers.length === 0) {
        setLoading(true);
      }
      
      // Check if Supabase is configured before making API calls
      const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
      const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;
      
      const isSupabaseConfigured = supabaseUrl && 
        supabaseAnonKey && 
        supabaseUrl !== 'your_supabase_project_url' && 
        supabaseAnonKey !== 'your_supabase_anon_key' &&
        supabaseUrl.startsWith('https://') && 
        supabaseUrl.includes('.supabase.co');
      
      if (!isSupabaseConfigured) {
        if (!silent) {
          setError('Supabase n\'est pas configuré. Veuillez cliquer sur "Connect to Supabase" pour configurer votre base de données.');
          setLoading(false);
        }
        return;
      }
      
      const data = await getConseillers();
      
      const conseillersWithStats = data.map(conseiller => ({
        ...conseiller,
        stats: getTransfertsStats(conseiller.transferts || [])
      }));

      setConseillers(conseillersWithStats);
      setLastUpdate(new Date());
      if (!silent) {
        setError(null); // Effacer les erreurs précédentes seulement lors d'actualisation manuelle
      }
    } catch (err) {
      console.error('Erreur lors du chargement:', err);
      if (!silent) {
        setError(err instanceof Error ? err.message : 'Erreur de connexion à la base de données');
      }
    } finally {
      if (!silent) {
        setLoading(false);
      }
    }
  };

  const filterConseillers = () => {
    let filtered = conseillers;

    if (searchTerm) {
      const term = searchTerm.toLowerCase();
      filtered = filtered.filter(c => 
        c.nom.toLowerCase().includes(term) || 
        c.prenom.toLowerCase().includes(term)
      );
    }

    if (statutFilter) {
      filtered = filtered.filter(c => c.statut === statutFilter);
    }

    if (assuranceFilter) {
      filtered = filtered.filter(c => {
        switch (assuranceFilter) {
          case 'vie': return c.assurance_vie;
          case 'hypothecaire': return c.assurance_hypothecaire;
          case 'invalidite': return c.assurance_invalidite;
          default: return true;
        }
      });
    }

    setFilteredConseillers(filtered);
  };

  const handleAddTransfert = (conseiller: ConseillerWithStats) => {
    setSelectedConseiller(conseiller);
    setShowTransfertModal(true);
  };

  const handleTransfertSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedConseiller) return;
    
    setIsSubmittingTransfert(true);
    try {
      await addTransfert({
        conseiller_id: selectedConseiller.id,
        nom_client: transfertData.nom_client,
        type_assurance: `Code: ${transfertData.code_telephoniste}`
      });
      
      setTransfertSuccess(`Transfert enregistré pour ${selectedConseiller.prenom} ${selectedConseiller.nom}`);
      setTransfertData({ nom_client: '', code_telephoniste: '' });
      setShowTransfertModal(false);
      setSelectedConseiller(null);
      
      // Recharger les données
      await loadConseillers();
      
      // Masquer le message de succès après 3 secondes
      setTimeout(() => setTransfertSuccess(null), 3000);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setIsSubmittingTransfert(false);
    }
  };

  const closeTransfertModal = () => {
    setShowTransfertModal(false);
    setSelectedConseiller(null);
    setTransfertData({ nom_client: '', code_telephoniste: '' });
  };

  const handleConseillerClick = (conseiller: ConseillerWithStats) => {
    setSelectedConseillerDetails(conseiller);
    setShowDetailsModal(true);
  };

  const closeDetailsModal = () => {
    setShowDetailsModal(false);
    setSelectedConseillerDetails(null);
  };

  const handleDeleteConseiller = (conseiller: ConseillerWithStats) => {
    setConseillerToDelete(conseiller);
    setShowDeleteModal(true);
  };

  const closeDeleteModal = () => {
    setShowDeleteModal(false);
    setConseillerToDelete(null);
    setDeleteConfirmText('');
  };

  const confirmDelete = async () => {
    if (!conseillerToDelete || deleteConfirmText !== 'SUPPRIMER') return;
    
    setIsDeleting(true);
    try {
      await deleteConseiller(conseillerToDelete.id);
      setShowDeleteModal(false);
      setConseillerToDelete(null);
      setDeleteConfirmText('');
      await loadConseillers();
    } catch (err: any) {
      setError(err.message);
    } finally {
      setIsDeleting(false);
    }
  };

  const getAllTransferts = (): TransfertWithConseiller[] => {
    const allTransferts: TransfertWithConseiller[] = [];
    conseillers.forEach(conseiller => {
      if (conseiller.transferts) {
        conseiller.transferts.forEach(transfert => {
          allTransferts.push({
            ...transfert,
            conseiller: {
              nom: conseiller.nom,
              prenom: conseiller.prenom
            }
          });
        });
      }
    });
    return allTransferts.sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime());
  };

  const getTransfertsByPeriod = (period: 'today' | 'week' | 'month'): TransfertWithConseiller[] => {
    // Date réelle : 20 août 2025
    const today = '2025-08-20';
    const now = new Date();
    
    const startOfWeek = new Date(now);
    startOfWeek.setDate(now.getDate() - now.getDay());
    
    const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1);
    
    const allTransferts = getAllTransferts();
    
    switch (period) {
      case 'today':
        return allTransferts.filter(t => t.date_transfert === today);
      case 'week':
        // Semaine du 18 au 24 août 2025 (lundi à dimanche)
        const weekStart = '2025-08-18';
        return allTransferts.filter(t => new Date(t.date_transfert) >= new Date(weekStart));
      case 'month':
        // Mois d'août 2025
        const monthStart = '2025-08-01';
        return allTransferts.filter(t => new Date(t.date_transfert) >= startOfMonth);
      default:
        return allTransferts;
    }
  };

  const handleShowTransferts = (period: 'today' | 'week' | 'month') => {
    const transferts = getTransfertsByPeriod(period);
    const titles = {
      today: "Transferts d'Aujourd'hui",
      week: "Transferts de Cette Semaine",
      month: "Transferts de Ce Mois"
    };
    
    setTransfertsModalData({
      title: titles[period],
      transferts
    });
    setShowTransfertsModal(true);
  };

  const closeTransfertsModal = () => {
    setShowTransfertsModal(false);
    setTransfertsModalData({ title: '', transferts: [] });
    setTransfertFilters({ conseiller: '', code: '', search: '' });
  };

  const getFilteredTransferts = () => {
    let filtered = transfertsModalData.transferts;

    if (transfertFilters.conseiller) {
      filtered = filtered.filter(t => 
        `${t.conseiller.prenom} ${t.conseiller.nom}`.toLowerCase().includes(transfertFilters.conseiller.toLowerCase())
      );
    }

    if (transfertFilters.code) {
      const code = transfertFilters.code.toLowerCase();
      filtered = filtered.filter(t => 
        t.type_assurance?.toLowerCase().includes(code)
      );
    }

    if (transfertFilters.search) {
      const search = transfertFilters.search.toLowerCase();
      filtered = filtered.filter(t => 
        t.nom_client.toLowerCase().includes(search)
      );
    }

    return filtered;
  };

  const getUniqueConseillers = () => {
    const conseillerNames = new Set<string>();
    transfertsModalData.transferts.forEach(t => {
      conseillerNames.add(`${t.conseiller.prenom} ${t.conseiller.nom}`);
    });
    return Array.from(conseillerNames).sort();
  };

  const getUniqueCodes = () => {
    const codes = new Set<string>();
    transfertsModalData.transferts.forEach(t => {
      if (t.type_assurance) {
        // Extraire le code après "Code: "
        const code = t.type_assurance.replace('Code: ', '');
        codes.add(code);
      }
    });
    return Array.from(codes).sort();
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('fr-FR', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric'
    });
  };

  const formatTime = (timeString: string) => {
    return timeString.slice(0, 5); // HH:MM
  };

  const getStatutColor = (statut: string) => {
    switch (statut) {
      case 'disponible': return 'text-green-600 bg-green-100 border-green-200';
      case 'indisponible': return 'text-red-600 bg-red-100 border-red-200';
      case 'avec_client': return 'text-yellow-600 bg-yellow-100 border-yellow-200';
      default: return 'text-slate-600 bg-slate-100 border-slate-200';
    }
  };

  const getStatutIcon = (statut: string) => {
    switch (statut) {
      case 'disponible': return '🟢';
      case 'indisponible': return '🔴';
      case 'avec_client': return '🟡';
      default: return '⚪';
    }
  };

  const getStatutLabel = (statut: string) => {
    switch (statut) {
      case 'disponible': return 'Disponible';
      case 'indisponible': return 'Indisponible';
      case 'avec_client': return 'Avec Client';
      default: return statut;
    }
  };

  const totalStats = conseillers.reduce((acc, c) => ({
    transferts_realises: acc.transferts_realises + c.stats.transferts_realises,
    transferts_aujourd_hui: acc.transferts_aujourd_hui + c.stats.transferts_aujourd_hui,
    transferts_semaine: acc.transferts_semaine + c.stats.transferts_semaine,
    transferts_mois: acc.transferts_mois + c.stats.transferts_mois,
  }), { transferts_realises: 0, transferts_aujourd_hui: 0, transferts_semaine: 0, transferts_mois: 0 });

  if (loading) {
    return (
      <Layout title="Chargement..." darkMode={darkMode}>
        <div className="text-center py-20">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p className="text-slate-600">Chargement du dashboard...</p>
        </div>
      </Layout>
    );
  }

  if (error) {
    return (
      <Layout title="Erreur de Configuration" darkMode={darkMode}>
        <div className="text-center py-20">
          <div className="bg-red-50 border border-red-200 rounded-xl p-8 max-w-md mx-auto">
            <h2 className="text-xl font-bold text-red-800 mb-4">Configuration Requise</h2>
            <p className="text-red-600 mb-6">{error}</p>
            <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
              <p className="text-sm text-blue-700 font-medium mb-2">Pour configurer Supabase:</p>
              <p className="text-sm text-blue-600">Cliquez sur "Connect to Supabase" en haut à droite</p>
            </div>
          </div>
        </div>
      </Layout>
    );
  }

  return (
    <Layout title="Dashboard Centre d'Appels" darkMode={darkMode}>
      {/* Bouton Dark Mode */}
      <div className="fixed top-4 right-4 z-50">
        <button
          onClick={toggleDarkMode}
          className={`p-3 rounded-full shadow-lg transition-all duration-300 hover:scale-110 ${
            darkMode 
              ? 'bg-yellow-500 text-white hover:bg-yellow-400' 
              : 'bg-slate-800 text-white hover:bg-slate-700'
          }`}
          title={darkMode ? 'Mode Clair' : 'Mode Sombre'}
        >
          {darkMode ? <Sun className="w-5 h-5" /> : <Moon className="w-5 h-5" />}
        </button>
      </div>

      {/* Message de succès global */}
      {transfertSuccess && (
        <div className="mb-6 bg-green-50 border border-green-200 rounded-xl p-4">
          <div className="flex items-center space-x-3 text-green-700">
            <CheckCircle className="w-5 h-5" />
            <span className="font-medium">{transfertSuccess}</span>
          </div>
        </div>
      )}

      {/* Bouton d'ajout de conseiller */}
      <div className="mb-6 flex items-center justify-between">
        <Link
          to="/enroll"
          className="inline-flex items-center space-x-2 bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700 transition-colors duration-200 font-medium shadow-lg"
        >
          <UserPlus className="w-5 h-5" />
          <span>Ajouter un Conseiller</span>
        </Link>
        
        <button
          onClick={() => loadConseillers(false)}
          disabled={loading}
          className="inline-flex items-center space-x-2 bg-green-600 text-white px-6 py-3 rounded-lg hover:bg-green-700 transition-colors duration-200 font-medium shadow-lg disabled:opacity-50"
        >
          <RefreshCw className={`w-5 h-5 ${loading ? 'animate-spin' : ''}`} />
          <span>{loading ? 'Actualisation...' : 'Actualiser'}</span>
        </button>
        
        <div className="text-sm text-slate-500">
          Dernière mise à jour: {lastUpdate.toLocaleTimeString('fr-FR')}
        </div>
      </div>

      {/* Numéro Principal */}
      <div className="bg-white rounded-xl shadow-lg p-6 mb-8">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <div className="bg-green-100 p-3 rounded-full">
              <span className="text-2xl">📞</span>
            </div>
            <div>
              <h3 className="text-lg font-bold text-slate-900">Numéro Principal</h3>
              <p className="text-2xl font-bold text-green-600 mb-1">14388058252</p>
              <p className="text-sm text-slate-600">
                En appelant ce numéro, vous appellerez tous les conseillers en même temps
              </p>
            </div>
          </div>
          <a
            href="tel:14388058252"
            className="bg-green-600 text-white px-6 py-3 rounded-lg hover:bg-green-700 transition-colors font-medium flex items-center space-x-2"
          >
            <span>📞</span>
            <span>Appeler</span>
          </a>
        </div>
      </div>

      {/* Statistiques Globales */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <div className="bg-white rounded-xl shadow-lg p-6">
          <div className="flex items-center space-x-3">
            <div className="bg-blue-100 p-3 rounded-lg">
              <Users className="w-6 h-6 text-blue-600" />
            </div>
            <div>
              <div className="text-2xl font-bold text-slate-900">{conseillers.length}</div>
              <div className="text-sm text-slate-600">Conseillers Actifs</div>
            </div>
          </div>
        </div>

        <div 
          className="bg-white rounded-xl shadow-lg p-6 cursor-pointer hover:shadow-xl transition-shadow duration-200"
          onClick={() => handleShowTransferts('today')}
        >
          <div className="flex items-center space-x-3">
            <div className="bg-green-100 p-3 rounded-lg">
              <TrendingUp className="w-6 h-6 text-green-600" />
            </div>
            <div>
              <div className="text-2xl font-bold text-slate-900">{totalStats.transferts_aujourd_hui}</div>
              <div className="text-sm text-slate-600">Transferts Aujourd'hui</div>
            </div>
          </div>
        </div>

        <div 
          className="bg-white rounded-xl shadow-lg p-6 cursor-pointer hover:shadow-xl transition-shadow duration-200"
          onClick={() => handleShowTransferts('week')}
        >
          <div className="flex items-center space-x-3">
            <div className="bg-purple-100 p-3 rounded-lg">
              <Clock className="w-6 h-6 text-purple-600" />
            </div>
            <div>
              <div className="text-2xl font-bold text-slate-900">{totalStats.transferts_semaine}</div>
              <div className="text-sm text-slate-600">Transferts Cette Semaine</div>
            </div>
          </div>
        </div>

        <div 
          className="bg-white rounded-xl shadow-lg p-6 cursor-pointer hover:shadow-xl transition-shadow duration-200"
          onClick={() => handleShowTransferts('month')}
        >
          <div className="flex items-center space-x-3">
            <div className="bg-yellow-100 p-3 rounded-lg">
              <Target className="w-6 h-6 text-yellow-600" />
            </div>
            <div>
              <div className="text-2xl font-bold text-slate-900">{totalStats.transferts_mois}</div>
              <div className="text-sm text-slate-600">Transferts Ce Mois</div>
            </div>
          </div>
        </div>
      </div>

      {/* Filtres et Recherche */}
      <div className="bg-white rounded-xl shadow-lg p-6 mb-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400 w-5 h-5" />
            <input
              type="text"
              placeholder="Rechercher un conseiller..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
          </div>

          <select
            value={statutFilter}
            onChange={(e) => setStatutFilter(e.target.value)}
            className="px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          >
            <option value="">Tous les statuts</option>
            <option value="disponible">Disponible</option>
            <option value="indisponible">Indisponible</option>
            <option value="avec_client">Avec Client</option>
          </select>

          <select
            value={assuranceFilter}
            onChange={(e) => setAssuranceFilter(e.target.value)}
            className="px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          >
            <option value="">Toutes les assurances</option>
            <option value="vie">Assurance Vie</option>
            <option value="hypothecaire">Assurance Hypothécaire</option>
            <option value="invalidite">Assurance Invalidité</option>
          </select>

          <div className="flex items-center space-x-2">
            <Filter className="w-5 h-5 text-slate-400" />
            <span className="text-sm text-slate-600">
              {filteredConseillers.length} sur {conseillers.length} conseillers
            </span>
          </div>
        </div>
      </div>

      {/* Liste des Conseillers */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredConseillers.map((conseiller) => (
          <div key={conseiller.id} className="bg-white rounded-xl shadow-lg overflow-hidden hover:shadow-xl transition-shadow duration-200">
            {/* Header avec Statut */}
            <div className="p-6 border-b border-slate-100">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center space-x-3">
                  <div className="bg-blue-100 p-2 rounded-lg">
                    <User className="w-5 h-5 text-blue-600" />
                  </div>
                  <div>
                    <h3 
                      className="text-lg font-bold text-slate-900 cursor-pointer hover:text-blue-600 transition-colors"
                      onClick={() => handleConseillerClick(conseiller)}
                    >
                      {conseiller.prenom} {conseiller.nom}
                    </h3>
                  </div>
                </div>
                <div className={`px-3 py-1 rounded-full border text-sm font-medium ${getStatutColor(conseiller.statut)}`}>
                  <span className="mr-1">{getStatutIcon(conseiller.statut)}</span>
                  {getStatutLabel(conseiller.statut)}
                </div>
              </div>

              {/* Informations de Contact */}
              <div className="space-y-2">
                <div className="flex items-center space-x-2 text-sm text-slate-600">
                  <Phone className="w-4 h-4" />
                  <span>{conseiller.telephone}</span>
                </div>
                <div className="flex items-center space-x-2 text-sm text-slate-600">
                  <Mail className="w-4 h-4" />
                  <span>{conseiller.email}</span>
                </div>
                <div className="flex items-center space-x-2 text-sm text-slate-600">
                  <MessageSquare className="w-4 h-4" />
                  <span className="capitalize">{conseiller.methode_comm}</span>
                </div>
              </div>
            </div>

            {/* Préférences d'Assurance */}
            <div className="p-4 bg-slate-50">
              <div className="flex flex-wrap gap-2">
                {conseiller.assurance_vie && (
                  <span className="px-2 py-1 bg-blue-100 text-blue-700 text-xs font-medium rounded">
                    Assurance Vie
                  </span>
                )}
                {conseiller.assurance_hypothecaire && (
                  <span className="px-2 py-1 bg-green-100 text-green-700 text-xs font-medium rounded">
                    Assurance Hypothécaire
                  </span>
                )}
                {conseiller.assurance_invalidite && (
                  <span className="px-2 py-1 bg-purple-100 text-purple-700 text-xs font-medium rounded">
                    Assurance Invalidité
                  </span>
                )}
              </div>
            </div>

            {/* Statistiques des Transferts */}
            <div className="p-6">
              <div className="grid grid-cols-2 gap-4 mb-4">
                <div className="text-center">
                  <div className="text-2xl font-bold text-blue-600">{conseiller.stats.transferts_realises}</div>
                  <div className="text-xs text-slate-500">Réalisés</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-slate-400">{conseiller.nb_transferts_demandes}</div>
                  <div className="text-xs text-slate-500">Objectif</div>
                </div>
              </div>

              <div className="grid grid-cols-3 gap-2 text-center">
                <div>
                  <div className="text-lg font-semibold text-green-600">{conseiller.stats.transferts_aujourd_hui}</div>
                  <div className="text-xs text-slate-500">Aujourd'hui</div>
                </div>
                <div>
                  <div className="text-lg font-semibold text-yellow-600">{conseiller.stats.transferts_semaine}</div>
                  <div className="text-xs text-slate-500">Semaine</div>
                </div>
                <div>
                  <div className="text-lg font-semibold text-purple-600">{conseiller.stats.transferts_mois}</div>
                  <div className="text-xs text-slate-500">Mois</div>
                </div>
              </div>

              {/* Progress Bar */}
              <div className="mt-4">
                <div className="flex justify-between text-xs text-slate-600 mb-1">
                  <span>Progression</span>
                  <span>{Math.round((conseiller.stats.transferts_realises / conseiller.nb_transferts_demandes) * 100)}%</span>
                </div>
                <div className="w-full bg-slate-200 rounded-full h-2">
                  <div 
                    className="bg-blue-600 h-2 rounded-full transition-all duration-300"
                    style={{ 
                      width: `${Math.min((conseiller.stats.transferts_realises / conseiller.nb_transferts_demandes) * 100, 100)}%`
                    }}
                  />
                </div>
              </div>
            </div>

            {/* Bouton d'ajout de transfert */}
            <div className="px-6 pb-4">
              <button
                onClick={() => handleAddTransfert(conseiller)}
                className="w-full bg-green-600 text-white py-2 px-3 rounded-lg hover:bg-green-700 transition-colors duration-200 font-medium text-sm flex items-center justify-center space-x-1"
              >
                <Plus className="w-4 h-4" />
                <span>Ajouter Transfert</span>
              </button>
            </div>

            {/* Bouton de suppression */}
            <div className="px-6 pb-4">
              <button
                onClick={() => handleDeleteConseiller(conseiller)}
                className="w-full bg-red-600 text-white py-2 px-3 rounded-lg hover:bg-red-700 transition-colors duration-200 font-medium text-sm flex items-center justify-center space-x-1"
              >
                <Trash2 className="w-4 h-4" />
                <span>Supprimer Conseiller</span>
              </button>
            </div>

            {/* Lien Personnel */}
            <div className="px-6 pb-6">
              {conseiller.notes && (
                <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-3 mb-3">
                  <div className="text-xs text-yellow-700 font-medium mb-1">Notes:</div>
                  <p className="text-xs text-yellow-800">{conseiller.notes}</p>
                </div>
              )}
              
              <div className="bg-slate-100 rounded-lg p-3">
                <div className="text-xs text-slate-500 mb-1">Lien personnel:</div>
                <code className="text-xs font-mono text-slate-700">/{conseiller.url_unique}</code>
              </div>
            </div>
          </div>
        ))}
      </div>

      {filteredConseillers.length === 0 && (
        <div className="text-center py-20">
          <div className="bg-slate-100 rounded-full w-20 h-20 flex items-center justify-center mx-auto mb-4">
            <Search className="w-10 h-10 text-slate-400" />
          </div>
          <h3 className="text-xl font-semibold text-slate-700 mb-2">Aucun conseiller trouvé</h3>
          <p className="text-slate-500">Essayez de modifier vos critères de recherche.</p>
        </div>
      )}

      {/* Modal d'ajout de transfert */}
      {showTransfertModal && selectedConseiller && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-xl shadow-xl max-w-md w-full">
            <div className="bg-gradient-to-r from-green-600 to-green-700 px-6 py-4 rounded-t-xl">
              <div className="flex items-center justify-between">
                <div>
                  <h2 className="text-xl font-bold text-white">Nouveau Transfert</h2>
                  <p className="text-green-100 text-sm">
                    {selectedConseiller.prenom} {selectedConseiller.nom}
                  </p>
                </div>
                <button
                  onClick={closeTransfertModal}
                  className="text-white hover:text-green-200 transition-colors"
                >
                  <X className="w-6 h-6" />
                </button>
              </div>
            </div>

            <form onSubmit={handleTransfertSubmit} className="p-6 space-y-4">
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">
                  Nom du Client *
                </label>
                <input
                  type="text"
                  required
                  value={transfertData.nom_client}
                  onChange={(e) => setTransfertData(prev => ({ ...prev, nom_client: e.target.value }))}
                  className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                  placeholder="Ex: Jean Dupont"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">
                  Code Téléphoniste *
                </label>
                <input
                  type="text"
                  required
                  value={transfertData.code_telephoniste}
                  onChange={(e) => setTransfertData(prev => ({ ...prev, code_telephoniste: e.target.value }))}
                  className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                  placeholder="Ex: TEL001"
                />
              </div>

              <div className="bg-blue-50 border border-blue-200 rounded-lg p-3">
                <p className="text-sm text-blue-700">
                  📅 <strong>Date et heure :</strong> Enregistrées automatiquement
                </p>
              </div>

              <div className="flex space-x-3 pt-4">
                <button
                  type="submit"
                  disabled={isSubmittingTransfert}
                  className="flex-1 bg-green-600 text-white py-3 px-4 rounded-lg hover:bg-green-700 transition-colors duration-200 font-medium disabled:opacity-50"
                >
                  {isSubmittingTransfert ? 'Enregistrement...' : 'Enregistrer'}
                </button>
                <button
                  type="button"
                  onClick={closeTransfertModal}
                  className="px-6 py-3 border border-slate-300 text-slate-700 rounded-lg hover:bg-slate-50 transition-colors duration-200"
                >
                  Annuler
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal liste des transferts par période */}
      {showTransfertsModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-xl shadow-xl max-w-6xl w-full max-h-[90vh] overflow-hidden">
            <div className="bg-gradient-to-r from-purple-600 to-purple-700 px-6 py-4 rounded-t-xl">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <div className="bg-white/20 p-2 rounded-lg">
                    <TrendingUp className="w-6 h-6 text-white" />
                  </div>
                  <div>
                    <h2 className="text-xl font-bold text-white">
                      {transfertsModalData.title}
                    </h2>
                    <p className="text-purple-100 text-sm">
                      {getFilteredTransferts().length} transfert(s) trouvé(s)
                    </p>
                  </div>
                </div>
                <button
                  onClick={closeTransfertsModal}
                  className="text-white hover:text-purple-200 transition-colors"
                >
                  <X className="w-6 h-6" />
                </button>
              </div>
            </div>

            <div className="p-6 overflow-y-auto max-h-[calc(90vh-120px)]">
              {/* Filtres */}
              <div className="bg-slate-50 rounded-lg p-4 mb-6">
                <h3 className="font-semibold text-slate-900 mb-4">Filtres</h3>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-2">
                      Conseiller
                    </label>
                    <select
                      value={transfertFilters.conseiller}
                      onChange={(e) => setTransfertFilters(prev => ({ ...prev, conseiller: e.target.value }))}
                      className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                    >
                      <option value="">Tous les conseillers</option>
                      {getUniqueConseillers().map(name => (
                        <option key={name} value={name}>{name}</option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-2">
                      Code Téléphoniste
                    </label>
                    <select
                      value={transfertFilters.code}
                      onChange={(e) => setTransfertFilters(prev => ({ ...prev, code: e.target.value }))}
                      className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                    >
                      <option value="">Tous les codes</option>
                      {getUniqueCodes().map(code => (
                        <option key={code} value={code}>{code}</option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-2">
                      Recherche Client
                    </label>
                    <div className="relative">
                      <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400 w-4 h-4" />
                      <input
                        type="text"
                        placeholder="Nom du client..."
                        value={transfertFilters.search}
                        onChange={(e) => setTransfertFilters(prev => ({ ...prev, search: e.target.value }))}
                        className="w-full pl-10 pr-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                      />
                    </div>
                  </div>
                </div>
              </div>

              {/* Liste des transferts */}
              {getFilteredTransferts().length > 0 ? (
                <div className="space-y-3">
                  {getFilteredTransferts().map((transfert, index) => (
                    <div key={transfert.id} className="bg-white border border-slate-200 rounded-lg p-4 hover:shadow-md transition-shadow">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-4">
                          <div className="bg-purple-100 text-purple-700 px-3 py-1 rounded-full text-sm font-medium">
                            #{index + 1}
                          </div>
                          <div>
                            <div className="font-semibold text-slate-900">
                              {transfert.nom_client}
                            </div>
                            <div className="text-sm text-slate-600">
                              Conseiller: {transfert.conseiller.prenom} {transfert.conseiller.nom}
                            </div>
                            {transfert.type_assurance && (
                              <div className="text-sm text-blue-600 font-medium">
                                {transfert.type_assurance}
                              </div>
                            )}
                          </div>
                        </div>
                        <div className="text-right">
                          <div className="text-sm font-medium text-slate-900">
                            {formatDate(transfert.date_transfert)}
                          </div>
                          <div className="text-sm text-slate-500">
                            {formatTime(transfert.heure_transfert)}
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-12">
                  <div className="bg-slate-100 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
                    <Search className="w-8 h-8 text-slate-400" />
                  </div>
                  <h4 className="text-lg font-medium text-slate-700 mb-2">Aucun transfert trouvé</h4>
                  <p className="text-slate-500">
                    Essayez de modifier vos critères de filtrage.
                  </p>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Modal détails conseiller */}
      {showDetailsModal && selectedConseillerDetails && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-xl shadow-xl max-w-4xl w-full max-h-[90vh] overflow-hidden">
            <div className="bg-gradient-to-r from-blue-600 to-blue-700 px-6 py-4 rounded-t-xl">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <div className="bg-white/20 p-2 rounded-lg">
                    <User className="w-6 h-6 text-white" />
                  </div>
                  <div>
                    <h2 className="text-xl font-bold text-white">
                      {selectedConseillerDetails.prenom} {selectedConseillerDetails.nom}
                    </h2>
                    <p className="text-blue-100 text-sm">
                      Détails et historique des transferts
                    </p>
                  </div>
                </div>
                <button
                  onClick={closeDetailsModal}
                  className="text-white hover:text-blue-200 transition-colors"
                >
                  <X className="w-6 h-6" />
                </button>
              </div>
            </div>

            <div className="p-6 overflow-y-auto max-h-[calc(90vh-120px)]">
              {/* Informations du conseiller */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
                <div className="bg-slate-50 rounded-lg p-4">
                  <h3 className="font-semibold text-slate-900 mb-3">Informations de Contact</h3>
                  <div className="space-y-2">
                    <div className="flex items-center space-x-2 text-sm">
                      <Phone className="w-4 h-4 text-slate-500" />
                      <span>{selectedConseillerDetails.telephone}</span>
                    </div>
                    <div className="flex items-center space-x-2 text-sm">
                      <Mail className="w-4 h-4 text-slate-500" />
                      <span>{selectedConseillerDetails.email}</span>
                    </div>
                    <div className="flex items-center space-x-2 text-sm">
                      <MessageSquare className="w-4 h-4 text-slate-500" />
                      <span className="capitalize">{selectedConseillerDetails.methode_comm}</span>
                    </div>
                  </div>
                </div>

                <div className="bg-slate-50 rounded-lg p-4">
                  <h3 className="font-semibold text-slate-900 mb-3">Statistiques</h3>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="text-center">
                      <div className="text-2xl font-bold text-blue-600">
                        {selectedConseillerDetails.stats.transferts_realises}
                      </div>
                      <div className="text-xs text-slate-500">Total Réalisés</div>
                    </div>
                    <div className="text-center">
                      <div className="text-2xl font-bold text-slate-400">
                        {selectedConseillerDetails.nb_transferts_demandes}
                      </div>
                      <div className="text-xs text-slate-500">Objectif</div>
                    </div>
                  </div>
                  <div className="mt-3">
                    <div className="flex justify-between text-xs text-slate-600 mb-1">
                      <span>Progression</span>
                      <span>
                        {Math.round((selectedConseillerDetails.stats.transferts_realises / selectedConseillerDetails.nb_transferts_demandes) * 100)}%
                      </span>
                    </div>
                    <div className="w-full bg-slate-200 rounded-full h-2">
                      <div 
                        className="bg-blue-600 h-2 rounded-full transition-all duration-300"
                        style={{ 
                          width: `${Math.min((selectedConseillerDetails.stats.transferts_realises / selectedConseillerDetails.nb_transferts_demandes) * 100, 100)}%`
                        }}
                      />
                    </div>
                  </div>
                </div>
              </div>

              {/* Liste des transferts */}
              <div>
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-lg font-semibold text-slate-900">
                    Historique des Transferts ({selectedConseillerDetails.transferts?.length || 0})
                  </h3>
                </div>

                {selectedConseillerDetails.transferts && selectedConseillerDetails.transferts.length > 0 ? (
                  <div className="space-y-3">
                    {selectedConseillerDetails.transferts
                      .map((transfert, index) => (
                        <div key={transfert.id} className="bg-gradient-to-r from-purple-50 to-blue-50 rounded-lg p-5 border border-purple-200">
                          <div className="flex items-start justify-between">
                            <div className="flex-1">
                              <div className="flex items-center space-x-3 mb-3">
                                <div className="bg-purple-100 p-2 rounded-lg">
                                  <Phone className="w-5 h-5 text-purple-600" />
                                </div>
                                <div>
                                  <h4 className="text-lg font-bold text-slate-900">
                                    Client: {transfert.nom_client}
                                  </h4>
                                  {transfert.type_assurance && (
                                    <p className="text-sm text-purple-600 font-medium">
                                      {transfert.type_assurance}
                                    </p>
                                  )}
                                </div>
                              </div>
                              
                              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4">
                                <div className="bg-white rounded-lg p-3 border border-slate-200">
                                  <p className="text-xs text-slate-500 uppercase tracking-wide font-medium mb-1">
                                    Date & Heure du Transfert
                                  </p>
                                  <p className="font-semibold text-slate-900">
                                    {new Date(transfert.date_transfert).toLocaleDateString('fr-FR', {
                                      weekday: 'long',
                                      year: 'numeric',
                                      month: 'long',
                                      day: 'numeric'
                                    })}
                                  </p>
                                  <p className="text-sm text-slate-600">
                                    à {transfert.heure_transfert}
                                  </p>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      ))}
                  </div>
                ) : (
                  <div className="text-center py-12">
                    <div className="bg-slate-100 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
                      <TrendingUp className="w-8 h-8 text-slate-400" />
                    </div>
                    <h4 className="text-lg font-medium text-slate-700 mb-2">Aucun transfert enregistré</h4>
                    <p className="text-slate-500">
                      Les transferts de ce conseiller apparaîtront ici une fois enregistrés.
                    </p>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Modal de confirmation de suppression */}
      {showDeleteModal && conseillerToDelete && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-xl shadow-xl max-w-md w-full">
            <div className="bg-gradient-to-r from-red-600 to-red-700 px-6 py-4 rounded-t-xl">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <div className="bg-white/20 p-2 rounded-lg">
                    <AlertTriangle className="w-6 h-6 text-white" />
                  </div>
                  <div>
                    <h2 className="text-xl font-bold text-white">Suppression Définitive</h2>
                    <p className="text-red-100 text-sm">Action irréversible</p>
                  </div>
                </div>
                <button
                  onClick={closeDeleteModal}
                  className="text-white hover:text-red-200 transition-colors"
                >
                  <X className="w-6 h-6" />
                </button>
              </div>
            </div>

            <div className="p-6">
              <div className="bg-red-50 border border-red-200 rounded-lg p-4 mb-6">
                <div className="flex items-start space-x-3">
                  <AlertTriangle className="w-5 h-5 text-red-600 mt-0.5" />
                  <div>
                    <h3 className="font-semibold text-red-800 mb-2">Attention !</h3>
                    <p className="text-sm text-red-700 mb-2">
                      Vous êtes sur le point de supprimer définitivement :
                    </p>
                    <div className="bg-white rounded-lg p-3 border border-red-200">
                      <div className="font-semibold text-slate-900">
                        {conseillerToDelete.prenom} {conseillerToDelete.nom}
                      </div>
                      <div className="text-sm text-slate-600">
                        {conseillerToDelete.email}
                      </div>
                      <div className="text-sm text-slate-600">
                        {conseillerToDelete.stats.transferts_realises} transferts réalisés
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4 mb-6">
                <h4 className="font-semibold text-yellow-800 mb-2">Cette action va :</h4>
                <ul className="text-sm text-yellow-700 space-y-1">
                  <li>• Supprimer définitivement le conseiller</li>
                  <li>• Supprimer tous ses transferts</li>
                  <li>• Désactiver son interface personnelle</li>
                  <li>• Cette action est <strong>irréversible</strong></li>
                </ul>
              </div>

              <div className="mb-6">
                <label className="block text-sm font-medium text-slate-700 mb-2">
                  Pour confirmer, tapez <strong>SUPPRIMER</strong> en majuscules :
                </label>
                <input
                  type="text"
                  value={deleteConfirmText}
                  onChange={(e) => setDeleteConfirmText(e.target.value)}
                  className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent"
                  placeholder="SUPPRIMER"
                />
              </div>

              <div className="flex space-x-3">
                <button
                  onClick={confirmDelete}
                  disabled={isDeleting || deleteConfirmText !== 'SUPPRIMER'}
                  className="flex-1 bg-red-600 text-white py-3 px-4 rounded-lg hover:bg-red-700 transition-colors duration-200 font-medium disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center space-x-2"
                >
                  {isDeleting ? (
                    <>
                      <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
                      <span>Suppression...</span>
                    </>
                  ) : (
                    <>
                      <Trash2 className="w-4 h-4" />
                      <span>Supprimer Définitivement</span>
                    </>
                  )}
                </button>
                <button
                  type="button"
                  onClick={closeDeleteModal}
                  disabled={isDeleting}
                  className="px-6 py-3 border border-slate-300 text-slate-700 rounded-lg hover:bg-slate-50 transition-colors duration-200 disabled:opacity-50"
                >
                  Annuler
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </Layout>
  );
}