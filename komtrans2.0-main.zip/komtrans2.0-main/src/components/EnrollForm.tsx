import React, { useState } from 'react';
import { supabase } from '../lib/supabase';
import { User, Phone, Mail, MessageSquare, FileText, CheckCircle, Headphones } from 'lucide-react';
import Layout from './Layout';

export default function EnrollForm() {
  const [formData, setFormData] = useState({
    nom: '',
    prenom: '',
    telephone: '',
    email: '',
    nb_transferts_demandes: 10,
    methode_comm: 'email' as 'email' | 'teams',
    assurance_vie: false,
    assurance_hypothecaire: false,
    assurance_invalidite: false,
    notes: ''
  });
  
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [success, setSuccess] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  const generateUrlUnique = (prenom: string, nom: string) => {
    return `${prenom.toLowerCase()}${nom.toLowerCase()}`.replace(/\s+/g, '');
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    setError(null);

    try {
      const urlUnique = generateUrlUnique(formData.prenom, formData.nom);
      
      const { error: insertError } = await supabase
        .from('conseillers')
        .insert({
          ...formData,
          url_unique: urlUnique,
          statut: 'disponible'
        });

      if (insertError) throw insertError;

      setSuccess(`Inscription réussie! Votre lien personnel: /${urlUnique}`);
      setFormData({
        nom: '',
        prenom: '',
        telephone: '',
        email: '',
        nb_transferts_demandes: 10,
        methode_comm: 'email',
        assurance_vie: false,
        assurance_hypothecaire: false,
        assurance_invalidite: false,
        notes: ''
      });
    } catch (err: any) {
      setError(err.message);
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value, type } = e.target;
    
    if (type === 'checkbox') {
      const checked = (e.target as HTMLInputElement).checked;
      setFormData(prev => ({ ...prev, [name]: checked }));
    } else if (type === 'number') {
      setFormData(prev => ({ ...prev, [name]: parseInt(value) || 0 }));
    } else {
      setFormData(prev => ({ ...prev, [name]: value }));
    }
  };

  if (success) {
    return (
      <Layout title="Inscription Réussie">
        <div className="max-w-md mx-auto">
          <div className="bg-white rounded-xl shadow-lg p-8 text-center">
            <div className="bg-green-100 p-3 rounded-full w-fit mx-auto mb-4">
              <CheckCircle className="w-8 h-8 text-green-600" />
            </div>
            <h2 className="text-2xl font-bold text-slate-900 mb-4">Inscription Réussie!</h2>
            <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-6">
              <p className="text-sm text-blue-700 font-medium mb-2">Votre lien personnel:</p>
              <code className="bg-blue-100 px-3 py-1 rounded font-mono text-blue-800">
                /{generateUrlUnique(formData.prenom, formData.nom)}
              </code>
            </div>
            <p className="text-slate-600 text-sm">
              Sauvegardez ce lien pour accéder à votre interface personnelle.
            </p>
          </div>
        </div>
      </Layout>
    );
  }

  return (
    <Layout title="Inscription Conseiller">
      <div className="max-w-2xl mx-auto">
        <div className="bg-white rounded-xl shadow-lg overflow-hidden">
          <div className="bg-gradient-to-r from-blue-600 to-blue-700 px-6 py-8">
            <div className="flex items-center space-x-3">
              <div className="bg-white/20 p-2 rounded-lg">
                <Headphones className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-2xl font-bold text-white">Inscription Conseiller</h1>
                <p className="text-blue-100">Rejoignez la plateforme KOM TRANSFER 2.0</p>
              </div>
            </div>
          </div>

          <form onSubmit={handleSubmit} className="p-6 space-y-6">
            {error && (
              <div className="bg-red-50 border border-red-200 rounded-lg p-4">
                <p className="text-red-600 text-sm">{error}</p>
              </div>
            )}

            {/* Informations Personnelles */}
            <div className="space-y-4">
              <h3 className="text-lg font-semibold text-slate-900 flex items-center space-x-2">
                <User className="w-5 h-5 text-blue-600" />
                <span>Informations Personnelles</span>
              </h3>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">
                    Nom *
                  </label>
                  <input
                    type="text"
                    name="nom"
                    required
                    value={formData.nom}
                    onChange={handleInputChange}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-colors"
                    placeholder="Dupont"
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">
                    Prénom *
                  </label>
                  <input
                    type="text"
                    name="prenom"
                    required
                    value={formData.prenom}
                    onChange={handleInputChange}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-colors"
                    placeholder="Jean"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">
                    <Phone className="w-4 h-4 inline mr-1" />
                    Téléphone *
                  </label>
                  <input
                    type="tel"
                    name="telephone"
                    required
                    value={formData.telephone}
                    onChange={handleInputChange}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-colors"
                    placeholder="514-555-0123"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">
                    <Mail className="w-4 h-4 inline mr-1" />
                    Courriel *
                  </label>
                  <input
                    type="email"
                    name="email"
                    required
                    value={formData.email}
                    onChange={handleInputChange}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-colors"
                    placeholder="jean.dupont@email.com"
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">
                  Nombre de transferts souhaités
                </label>
                <input
                  type="number"
                  name="nb_transferts_demandes"
                  min="1"
                  value={formData.nb_transferts_demandes}
                  onChange={handleInputChange}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-colors"
                />
              </div>
            </div>

            {/* Méthode de Communication */}
            <div className="space-y-4">
              <h3 className="text-lg font-semibold text-slate-900 flex items-center space-x-2">
                <MessageSquare className="w-5 h-5 text-blue-600" />
                <span>Méthode de Communication</span>
              </h3>
              
              <div className="flex space-x-6">
                <label className="flex items-center">
                  <input
                    type="radio"
                    name="methode_comm"
                    value="email"
                    checked={formData.methode_comm === 'email'}
                    onChange={handleInputChange}
                    className="w-4 h-4 text-blue-600 border-slate-300 focus:ring-blue-500"
                  />
                  <span className="ml-2 text-sm text-slate-700">Courriel</span>
                </label>
                
                <label className="flex items-center">
                  <input
                    type="radio"
                    name="methode_comm"
                    value="teams"
                    checked={formData.methode_comm === 'teams'}
                    onChange={handleInputChange}
                    className="w-4 h-4 text-blue-600 border-slate-300 focus:ring-blue-500"
                  />
                  <span className="ml-2 text-sm text-slate-700">Teams</span>
                </label>
              </div>
            </div>

            {/* Préférences d'Assurance */}
            <div className="space-y-4">
              <h3 className="text-lg font-semibold text-slate-900">Préférences d'Assurance</h3>
              
              <div className="space-y-3">
                <label className="flex items-center p-3 bg-slate-50 rounded-lg hover:bg-slate-100 transition-colors cursor-pointer">
                  <input
                    type="checkbox"
                    name="assurance_vie"
                    checked={formData.assurance_vie}
                    onChange={handleInputChange}
                    className="w-4 h-4 text-blue-600 border-slate-300 rounded focus:ring-blue-500"
                  />
                  <span className="ml-3 text-sm text-slate-700 font-medium">Assurance Vie</span>
                </label>
                
                <label className="flex items-center p-3 bg-slate-50 rounded-lg hover:bg-slate-100 transition-colors cursor-pointer">
                  <input
                    type="checkbox"
                    name="assurance_hypothecaire"
                    checked={formData.assurance_hypothecaire}
                    onChange={handleInputChange}
                    className="w-4 h-4 text-blue-600 border-slate-300 rounded focus:ring-blue-500"
                  />
                  <span className="ml-3 text-sm text-slate-700 font-medium">Assurance Hypothécaire</span>
                </label>
                
                <label className="flex items-center p-3 bg-slate-50 rounded-lg hover:bg-slate-100 transition-colors cursor-pointer">
                  <input
                    type="checkbox"
                    name="assurance_invalidite"
                    checked={formData.assurance_invalidite}
                    onChange={handleInputChange}
                    className="w-4 h-4 text-blue-600 border-slate-300 rounded focus:ring-blue-500"
                  />
                  <span className="ml-3 text-sm text-slate-700 font-medium">Assurance Invalidité</span>
                </label>
              </div>
            </div>

            {/* Notes Additionnelles */}
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-2">
                <FileText className="w-4 h-4 inline mr-1" />
                Notes Additionnelles
              </label>
              <textarea
                name="notes"
                rows={4}
                value={formData.notes}
                onChange={handleInputChange}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-colors"
                placeholder="Informations supplémentaires..."
              />
            </div>

            <div className="pt-6">
              <button
                type="submit"
                disabled={isSubmitting}
                className="w-full bg-blue-600 text-white py-3 px-4 rounded-lg hover:bg-blue-700 focus:ring-4 focus:ring-blue-200 transition-all duration-200 font-medium disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {isSubmitting ? 'Inscription en cours...' : "S'inscrire"}
              </button>
            </div>
          </form>
        </div>
      </div>
    </Layout>
  );
}