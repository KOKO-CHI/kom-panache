import React, { useState, useEffect } from 'react';
import { Calendar, Filter, BarChart3, TrendingUp, Users, Clock, Trash2 } from 'lucide-react';
import { supabase, getConseillers, deleteTransfert } from '../lib/supabase';
import { Conseiller, Transfert } from '../types';
import Layout from './Layout';

export default function StatsPage() {
  const [conseillers, setConseillers] = useState<Conseiller[]>([]);
  const [filteredTransferts, setFilteredTransferts] = useState<Transfert[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [deletingId, setDeletingId] = useState<string | null>(null);
  
  // Filtres
  const [selectedCode, setSelectedCode] = useState<string>('all');
  const [dateDebut, setDateDebut] = useState(() => {
    // Date actuelle en heure de Montréal par défaut
    const montrealNow = new Date().toLocaleString("en-US", {timeZone: "America/Montreal"});
    const today = new Date(montrealNow);
    return today.toISOString().split('T')[0];
  });
  const [dateFin, setDateFin] = useState(() => {
    // Date actuelle en heure de Montréal par défaut
    const montrealNow = new Date().toLocaleString("en-US", {timeZone: "America/Montreal"});
    const today = new Date(montrealNow);
    return today.toISOString().split('T')[0];
  });
  const [selectedConseiller, setSelectedConseiller] = useState<string>('all');

  useEffect(() => {
    loadData();
  }, []);

  useEffect(() => {
    filterTransferts();
  }, [conseillers, selectedCode, dateDebut, dateFin, selectedConseiller]);

  const loadData = async () => {
    try {
      setLoading(true);
      const data = await getConseillers();
      setConseillers(data);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const getUniqueCodes = () => {
    let allCodes: string[] = [];
    conseillers.forEach(conseiller => {
      if (conseiller.transferts) {
        conseiller.transferts.forEach(transfert => {
          if (transfert.type_assurance && !allCodes.includes(transfert.type_assurance)) {
            allCodes.push(transfert.type_assurance);
          }
        });
      }
    });
    return allCodes.sort();
  };

  const filterTransferts = () => {
    let allTransferts: Transfert[] = [];
    
    conseillers.forEach(conseiller => {
      if (conseiller.transferts) {
        const transfertsWithConseiller = conseiller.transferts.map(t => ({
          ...t,
          conseiller_nom: `${conseiller.prenom} ${conseiller.nom}`,
        }));
        allTransferts = [...allTransferts, ...transfertsWithConseiller];
      }
    });

    // Filtrer par conseiller
    if (selectedConseiller !== 'all') {
      allTransferts = allTransferts.filter(t => t.conseiller_id === selectedConseiller);
    }

    // Filtrer par code de transfert
    if (selectedCode !== 'all') {
      allTransferts = allTransferts.filter(t => t.type_assurance === selectedCode);
    }

    // Filtrer par période de dates
    if (dateDebut && dateFin) {
      // Filtrer entre les deux dates (incluses)
      allTransferts = allTransferts.filter(t => 
        t.date_transfert >= dateDebut && t.date_transfert <= dateFin
      );
    } else if (dateDebut) {
      // Filtrer à partir de la date de début
      allTransferts = allTransferts.filter(t => t.date_transfert >= dateDebut);
    } else if (dateFin) {
      // Filtrer jusqu'à la date de fin
      allTransferts = allTransferts.filter(t => t.date_transfert <= dateFin);
    }

    setFilteredTransferts(allTransferts);
  };

  const handleDeleteTransfert = async (transfertId: string) => {
    if (!confirm('Êtes-vous sûr de vouloir supprimer ce transfert ?')) {
      return;
    }

    setDeletingId(transfertId);
    try {
      await deleteTransfert(transfertId);
      // Recharger les données
      await loadData();
    } catch (err: any) {
      setError(err.message);
    } finally {
      setDeletingId(null);
    }
  };

  const getGlobalStats = () => {
    const montrealNow = new Date().toLocaleString("en-US", {timeZone: "America/Montreal"});
    const today = new Date(montrealNow);
    const todayString = today.toISOString().split('T')[0];
    
    // Début de la semaine (lundi)
    const startOfWeek = new Date(today);
    const dayOfWeek = today.getDay();
    const daysToMonday = dayOfWeek === 0 ? 6 : dayOfWeek - 1;
    startOfWeek.setDate(today.getDate() - daysToMonday);
    const startOfWeekString = startOfWeek.toISOString().split('T')[0];
    
    // Début du mois
    const startOfMonth = new Date(today.getFullYear(), today.getMonth(), 1);
    const startOfMonthString = startOfMonth.toISOString().split('T')[0];
    
    let allTransferts: Transfert[] = [];
    conseillers.forEach(conseiller => {
      if (conseiller.transferts) {
        allTransferts = [...allTransferts, ...conseiller.transferts];
      }
    });

    return {
      total: allTransferts.length,
      today: allTransferts.filter(t => t.date_transfert === todayString).length,
      week: allTransferts.filter(t => t.date_transfert >= startOfWeekString).length,
      month: allTransferts.filter(t => t.date_transfert >= startOfMonthString).length,
    };
  };

  if (loading) {
    return (
      <Layout title="Statistiques">
        <div className="flex items-center justify-center py-12">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
        </div>
      </Layout>
    );
  }

  if (error) {
    return (
      <Layout title="Statistiques">
        <div className="bg-red-50 border border-red-200 rounded-lg p-4">
          <p className="text-red-600">{error}</p>
        </div>
      </Layout>
    );
  }

  const globalStats = getGlobalStats();

  return (
    <Layout title="Statistiques Détaillées">
      <div className="space-y-8">
        {/* En-tête */}
        <div className="bg-white rounded-xl shadow-lg p-6">
          <div className="flex items-center space-x-3 mb-6">
            <div className="bg-blue-600 p-2 rounded-lg">
              <BarChart3 className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-2xl font-bold text-slate-900">Statistiques Détaillées</h1>
              <p className="text-slate-600">Analyse complète des transferts</p>
            </div>
          </div>

          {/* Statistiques globales */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="bg-gradient-to-br from-blue-500 to-blue-600 text-white p-4 rounded-lg">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-blue-100 text-sm">Total</p>
                  <p className="text-2xl font-bold">{globalStats.total}</p>
                </div>
                <TrendingUp className="w-8 h-8 text-blue-200" />
              </div>
            </div>

            <div className="bg-gradient-to-br from-green-500 to-green-600 text-white p-4 rounded-lg">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-green-100 text-sm">Aujourd'hui</p>
                  <p className="text-2xl font-bold">{globalStats.today}</p>
                </div>
                <Clock className="w-8 h-8 text-green-200" />
              </div>
            </div>

            <div className="bg-gradient-to-br from-orange-500 to-orange-600 text-white p-4 rounded-lg">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-orange-100 text-sm">Cette Semaine</p>
                  <p className="text-2xl font-bold">{globalStats.week}</p>
                </div>
                <Calendar className="w-8 h-8 text-orange-200" />
              </div>
            </div>

            <div className="bg-gradient-to-br from-purple-500 to-purple-600 text-white p-4 rounded-lg">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-purple-100 text-sm">Ce Mois</p>
                  <p className="text-2xl font-bold">{globalStats.month}</p>
                </div>
                <Users className="w-8 h-8 text-purple-200" />
              </div>
            </div>
          </div>
        </div>

        {/* Filtres */}
        <div className="bg-white rounded-xl shadow-lg p-6">
          <div className="flex items-center space-x-2 mb-4">
            <Filter className="w-5 h-5 text-slate-600" />
            <h2 className="text-lg font-semibold text-slate-900">Filtres</h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {/* Code de transfert */}
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-2">
                Code de transfert
              </label>
              <select
                value={selectedCode}
                onChange={(e) => setSelectedCode(e.target.value)}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              >
                <option value="all">Tous les codes</option>
                {getUniqueCodes().map(code => (
                  <option key={code} value={code}>
                    {code}
                  </option>
                ))}
              </select>
            </div>

            {/* Conseiller */}
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-2">
                Conseiller
              </label>
              <select
                value={selectedConseiller}
                onChange={(e) => setSelectedConseiller(e.target.value)}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              >
                <option value="all">Tous les conseillers</option>
                {conseillers.map(conseiller => (
                  <option key={conseiller.id} value={conseiller.id}>
                    {conseiller.prenom} {conseiller.nom}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Période de dates */}
          <div className="mt-4">
            <h4 className="text-sm font-medium text-slate-700 mb-3">Période</h4>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">
                  Du
                </label>
                <input
                  type="date"
                  value={dateDebut}
                  onChange={(e) => setDateDebut(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">
                  Au
                </label>
                <input
                  type="date"
                  value={dateFin}
                  onChange={(e) => setDateFin(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              </div>
            </div>
            
            {(dateDebut || dateFin) && (
              <div className="mt-3 text-sm text-slate-600 bg-blue-50 p-3 rounded-lg">
                <p className="font-medium text-blue-800 mb-1">📅 Période sélectionnée :</p>
                {dateDebut && dateFin ? (
                  <p>Du <strong>{new Date(dateDebut + 'T00:00:00').toLocaleDateString('fr-CA')}</strong> au <strong>{new Date(dateFin + 'T00:00:00').toLocaleDateString('fr-CA')}</strong></p>
                ) : dateDebut ? (
                  <p>À partir du <strong>{new Date(dateDebut + 'T00:00:00').toLocaleDateString('fr-CA')}</strong></p>
                ) : (
                  <p>Jusqu'au <strong>{new Date(dateFin + 'T00:00:00').toLocaleDateString('fr-CA')}</strong></p>
                )}
              </div>
            )}
          </div>
        </div>

        {/* Résultats */}
        <div className="bg-white rounded-xl shadow-lg p-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-semibold text-slate-900">
              Transferts Filtrés ({filteredTransferts.length})
            </h2>
            <div className="text-sm text-slate-600">
              {(dateDebut || dateFin) && (
                dateDebut && dateFin ? `Période: ${dateDebut} au ${dateFin}` :
                dateDebut ? `À partir du: ${dateDebut}` :
                `Jusqu'au: ${dateFin}`
              )}
              {selectedCode !== 'all' && ` | Code de transfert: ${selectedCode}`}
            </div>
          </div>

          {filteredTransferts.length === 0 ? (
            <div className="text-center py-8">
              <div className="bg-slate-100 p-3 rounded-full w-fit mx-auto mb-3">
                <BarChart3 className="w-6 h-6 text-slate-400" />
              </div>
              <p className="text-slate-600">Aucun transfert trouvé pour les critères sélectionnés</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-slate-200">
                    <th className="text-left py-3 px-4 font-medium text-slate-700">Date</th>
                    <th className="text-left py-3 px-4 font-medium text-slate-700">Heure</th>
                    <th className="text-left py-3 px-4 font-medium text-slate-700">Client</th>
                    <th className="text-left py-3 px-4 font-medium text-slate-700">Code</th>
                    <th className="text-left py-3 px-4 font-medium text-slate-700">Conseiller</th>
                    <th className="text-left py-3 px-4 font-medium text-slate-700">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {filteredTransferts.map((transfert, index) => (
                    <tr key={transfert.id} className={index % 2 === 0 ? 'bg-slate-50' : 'bg-white'}>
                      <td className="py-3 px-4 text-slate-900">
                        {new Date(transfert.date_transfert + 'T00:00:00').toLocaleDateString('fr-CA')}
                      </td>
                      <td className="py-3 px-4 text-slate-600">
                        {transfert.heure_transfert}
                      </td>
                      <td className="py-3 px-4 text-slate-900 font-medium">
                        {transfert.nom_client}
                      </td>
                      <td className="py-3 px-4">
                        <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800 font-mono">
                          {transfert.type_assurance || 'N/A'}
                        </span>
                      </td>
                      <td className="py-3 px-4 text-slate-600">
                        {(transfert as any).conseiller_nom || 'N/A'}
                      </td>
                      <td className="py-3 px-4">
                        <button
                          onClick={() => handleDeleteTransfert(transfert.id)}
                          disabled={deletingId === transfert.id}
                          className="text-red-600 hover:text-red-800 hover:bg-red-50 p-2 rounded-lg transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                          title="Supprimer ce transfert"
                        >
                          {deletingId === transfert.id ? (
                            <div className="animate-spin rounded-full h-4 w-4 border-2 border-red-300 border-t-red-600"></div>
                          ) : (
                            <Trash2 className="w-4 h-4" />
                          )}
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>
    </Layout>
  );
}