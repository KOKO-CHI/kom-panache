import React from 'react';
import { Headphones, Users, TrendingUp } from 'lucide-react';

interface LayoutProps {
  children: React.ReactNode;
  title: string;
  showHeader?: boolean;
  darkMode?: boolean;
}

export default function Layout({ children, title, showHeader = true, darkMode = false }: LayoutProps) {
  return (
    <div className={`min-h-screen transition-colors duration-300 ${
      darkMode 
        ? 'bg-gradient-to-br from-slate-900 to-slate-800' 
        : 'bg-gradient-to-br from-slate-50 to-blue-50'
    }`}>
      {showHeader && (
        <header className={`shadow-sm border-b transition-colors duration-300 ${
          darkMode 
            ? 'bg-slate-800 border-slate-700' 
            : 'bg-white border-slate-200'
        }`}>
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <div className={`p-2 rounded-lg ${
                  darkMode ? 'bg-blue-500' : 'bg-blue-600'
                }`}>
                  <Headphones className="w-6 h-6 text-white" />
                </div>
                <div>
                  <h1 className={`text-2xl font-bold ${darkMode ? 'text-white' : 'text-slate-900'}`}>
                    KOM TRANSFER 2.0
                  </h1>
                  <p className={`text-sm ${darkMode ? 'text-slate-400' : 'text-slate-600'}`}>
                    Plateforme de Gestion des Conseillers
                  </p>
                </div>
              </div>
              <div className="flex items-center space-x-6">
                <div className={`flex items-center space-x-2 ${darkMode ? 'text-slate-400' : 'text-slate-600'}`}>
                  <Users className="w-5 h-5" />
                  <span className="text-sm font-medium">{title}</span>
                </div>
              </div>
            </div>
          </div>
        </header>
      )}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {children}
      </main>
    </div>
  );
}