import React, { useState, useEffect } from 'react';
import { Calendar, Clock, Users, BarChart3, Filter, User, CheckCircle, AlertCircle, Timer, Watch } from 'lucide-react';
import { supabase, getConseillers, calculateRealAvailabilityStats } from '../lib/supabase';
import { Conseiller } from '../types';
import Layout from './Layout';

export default function DispoPage() {
  const [conseillers, setConseillers] = useState<Conseiller[]>([]);
  const [stats, setStats] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [currentTime, setCurrentTime] = useState(new Date());
  
  // Filtres de période
  const [dateDebut, setDateDebut] = useState(() => {
    // Date actuelle en heure de Montréal
    const montrealNow = new Date().toLocaleString("en-US", {timeZone: "America/Montreal"});
    const today = new Date(montrealNow);
    return today.toISOString().split('T')[0];
  });
  
  const [dateFin, setDateFin] = useState(() => {
    // Date actuelle en heure de Montréal
    const montrealNow = new Date().toLocaleString("en-US", {timeZone: "America/Montreal"});
    const today = new Date(montrealNow);
    return today.toISOString().split('T')[0];
  });
  
  const [selectedConseillers, setSelectedConseillers] = useState<string[]>([]);

  // Fonction pour calculer le nombre de disponibles par heure
  const calculateHourlyAvailability = () => {
    const hourlyData = [];
    
    // Pour chaque heure de 9h à 20h
    for (let hour = 9; hour <= 20; hour++) {
      let disponiblesCount = 0;
      
      // Compter combien de conseillers sont disponibles à cette heure
      const conseillersToCheck = selectedConseillers.length > 0 
        ? conseillers.filter(c => selectedConseillers.includes(c.id))
        : conseillers;
      
      conseillersToCheck.forEach(conseiller => {
        // Pour simplifier, on considère le statut actuel
        // Dans une vraie implémentation, on vérifierait l'historique pour cette heure précise
        if (conseiller.statut === 'disponible') {
          disponiblesCount++;
        }
      });
      
      hourlyData.push({
        heure: `${hour}:00`,
        disponibles: disponiblesCount,
        total: conseillersToCheck.length
      });
    }
    
    return hourlyData;
  };

  const getInitials = (prenom: string, nom: string) => {
    return `${prenom[0]}${nom[0]}`;
  };

  useEffect(() => {
    loadData();
  }, []);

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date());
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  useEffect(() => {
    if (conseillers.length > 0) {
      loadStats();
    }
  }, [conseillers, dateDebut, dateFin, selectedConseillers]);

  const loadData = async () => {
    try {
      setLoading(true);
      
      // Vérifier si Supabase est configuré
      if (!import.meta.env.VITE_SUPABASE_URL || !import.meta.env.VITE_SUPABASE_ANON_KEY) {
        setError('Supabase n\'est pas configuré. Veuillez cliquer sur "Connect to Supabase" pour configurer votre base de données.');
        return;
      }
      
      const data = await getConseillers();
      setConseillers(data);
    } catch (err: any) {
      // Gestion spécifique des erreurs de connexion
      if (err.message?.includes('Failed to fetch') || err.message?.includes('fetch')) {
        setError('Impossible de se connecter à la base de données. Veuillez vérifier votre connexion Supabase et cliquer sur "Connect to Supabase" si nécessaire.');
      } else {
        setError(err.message || 'Une erreur est survenue lors du chargement des données.');
      }
    } finally {
      setLoading(false);
    }
  };

  const loadStats = async () => {
    try {
      // Vérifier si Supabase est configuré avant de faire des requêtes
      if (!import.meta.env.VITE_SUPABASE_URL || !import.meta.env.VITE_SUPABASE_ANON_KEY) {
        setError('Supabase n\'est pas configuré. Veuillez cliquer sur "Connect to Supabase" pour configurer votre base de données.');
        setStats([]);
        return;
      }
      
      // Filtrer les conseillers sélectionnés
      const conseillersToAnalyze = selectedConseillers.length > 0 
        ? conseillers.filter(c => selectedConseillers.includes(c.id))
        : conseillers;
      
      if (conseillersToAnalyze.length > 0) {
        // Récupérer les vraies statistiques depuis la base de données
        const statsCalculees = await calculateRealAvailabilityStats(
          conseillersToAnalyze.map(c => c.id), 
          dateDebut, 
          dateFin
        );
        setStats(statsCalculees);
      } else {
        setStats([]);
      }
    } catch (err: any) {
      console.error('Erreur lors du calcul des stats:', err);
      // Gestion spécifique des erreurs de connexion
      if (err.message?.includes('Failed to fetch') || err.message?.includes('fetch')) {
        setError('Impossible de se connecter à la base de données. Veuillez vérifier votre connexion Supabase.');
      } else {
        setError(err.message || 'Une erreur est survenue lors du calcul des statistiques.');
      }
      setStats([]);
    }
  };

  const handleConseillerToggle = (conseillerId: string) => {
    setSelectedConseillers(prev => {
      if (prev.includes(conseillerId)) {
        return prev.filter(id => id !== conseillerId);
      } else {
        return [...prev, conseillerId];
      }
    });
  };

  const handleSelectAll = () => {
    if (selectedConseillers.length === conseillers.length) {
      setSelectedConseillers([]);
    } else {
      setSelectedConseillers(conseillers.map(c => c.id));
    }
  };

  const getStatutColor = (statut: string) => {
    switch (statut) {
      case 'disponible':
        return 'text-emerald-600 bg-emerald-50';
      case 'avec_client':
        return 'text-amber-600 bg-amber-50';
      case 'indisponible':
        return 'text-red-600 bg-red-50';
      default:
        return 'text-slate-600 bg-slate-50';
    }
  };

  const getStatutIcon = (statut: string) => {
    switch (statut) {
      case 'disponible':
        return <CheckCircle className="w-4 h-4" />;
      case 'avec_client':
        return <Timer className="w-4 h-4" />;
      case 'indisponible':
        return <AlertCircle className="w-4 h-4" />;
      default:
        return <Clock className="w-4 h-4" />;
    }
  };

  const getTotalStats = () => {
    const totaux = stats.reduce((acc, stat) => ({
      heures_disponible: acc.heures_disponible + stat.heures_disponible,
      heures_indisponible: acc.heures_indisponible + stat.heures_indisponible,
      heures_avec_client: acc.heures_avec_client + stat.heures_avec_client,
      total_heures: acc.total_heures + stat.total_heures,
    }), {
      heures_disponible: 0,
      heures_indisponible: 0,
      heures_avec_client: 0,
      total_heures: 0,
    });

    return {
      ...totaux,
      pourcentage_disponible: totaux.total_heures > 0 ? Math.round((totaux.heures_disponible / totaux.total_heures) * 100) : 0,
      pourcentage_indisponible: totaux.total_heures > 0 ? Math.round((totaux.heures_indisponible / totaux.total_heures) * 100) : 0,
      pourcentage_avec_client: totaux.total_heures > 0 ? Math.round((totaux.heures_avec_client / totaux.total_heures) * 100) : 0,
    };
  };

  const formatDateTime = (date: Date) => {
    const options: Intl.DateTimeFormatOptions = {
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
      timeZone: 'America/Montreal'
    };
    return date.toLocaleDateString('fr-CA', options);
  };

  if (loading) {
    return (
      <Layout title="Statistiques de Disponibilité">
        <div className="flex items-center justify-center py-12">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
        </div>
      </Layout>
    );
  }

  if (error) {
    return (
      <Layout title="Statistiques de Disponibilité">
        <div className="bg-red-50 border border-red-200 rounded-lg p-4">
          <p className="text-red-600">{error}</p>
        </div>
      </Layout>
    );
  }

  const totalStats = getTotalStats();

  return (
    <Layout title="Statistiques de Disponibilité">
      <div className="space-y-8">
        {/* Horloge en temps réel */}
        <div className="bg-gradient-to-r from-indigo-600 to-purple-600 rounded-xl shadow-lg p-6 text-white">
          <div className="flex items-center justify-center space-x-4">
            <div className="bg-white/20 p-3 rounded-full">
              <Watch className="w-8 h-8 text-white" />
            </div>
            <div className="text-center">
              <h2 className="text-3xl font-bold font-mono tracking-wider">
                {currentTime.toLocaleTimeString('fr-CA', { 
                  timeZone: 'America/Montreal',
                  hour12: false 
                })}
              </h2>
              <p className="text-indigo-100 text-lg capitalize">
                {formatDateTime(currentTime)}
              </p>
            </div>
          </div>
        </div>

        {/* En-tête */}
        <div className="bg-white rounded-xl shadow-lg p-6">
          <div className="flex items-center space-x-3 mb-6">
            <div className="bg-purple-600 p-2 rounded-lg">
              <BarChart3 className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-2xl font-bold text-slate-900">Statistiques de Disponibilité</h1>
              <p className="text-slate-600">Analyse des temps de disponibilité des conseillers</p>
            </div>
          </div>

          {/* Sélection de période */}
          <div className="bg-slate-50 rounded-lg p-4">
            <div className="flex items-center space-x-2 mb-4">
              <Calendar className="w-5 h-5 text-slate-600" />
              <h3 className="text-lg font-semibold text-slate-900">Période d'Analyse</h3>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">
                  Du
                </label>
                <input
                  type="date"
                  value={dateDebut}
                  onChange={(e) => setDateDebut(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">
                  Au
                </label>
                <input
                  type="date"
                  value={dateFin}
                  onChange={(e) => setDateFin(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                />
              </div>
            </div>
            
            <div className="mt-3 text-sm text-slate-600 bg-blue-50 p-3 rounded-lg">
              <p className="font-medium text-blue-800 mb-1">📋 Informations importantes :</p>
              <p>• Heures de travail : <strong>9h00 à 20h00</strong> (11h par jour)</p>
              <p>• Période sélectionnée : <strong>{Math.ceil((new Date(dateFin).getTime() - new Date(dateDebut).getTime()) / (1000 * 60 * 60 * 24)) + 1} jour(s)</strong></p>
              <p className="text-green-700 mt-2">✅ <strong>Données réelles :</strong> Basées sur l'historique des changements de statut.</p>
            </div>
          </div>
        </div>

        {/* Filtre Conseillers */}
        <div className="bg-white rounded-xl shadow-lg p-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-semibold text-slate-900 flex items-center space-x-2">
              <Users className="w-5 h-5 text-purple-600" />
              <span>Sélection des Conseillers</span>
            </h2>
            <button
              onClick={handleSelectAll}
              className="text-sm bg-purple-100 text-purple-700 px-3 py-1 rounded-lg hover:bg-purple-200 transition-colors"
            >
              {selectedConseillers.length === conseillers.length ? 'Désélectionner tout' : 'Sélectionner tout'}
            </button>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
            {conseillers.map(conseiller => (
              <label
                key={conseiller.id}
                className="flex items-center space-x-3 p-3 bg-slate-50 rounded-lg hover:bg-slate-100 transition-colors cursor-pointer"
              >
                <input
                  type="checkbox"
                  checked={selectedConseillers.includes(conseiller.id)}
                  onChange={() => handleConseillerToggle(conseiller.id)}
                  className="w-4 h-4 text-purple-600 border-slate-300 rounded focus:ring-purple-500"
                />
                <div className="flex items-center space-x-2 flex-1">
                  <div className="w-8 h-8 bg-gradient-to-br from-blue-500 to-indigo-600 rounded-full flex items-center justify-center">
                    <span className="text-white font-bold text-xs">
                      {conseiller.prenom[0]}{conseiller.nom[0]}
                    </span>
                  </div>
                  <div className="flex-1">
                    <p className="font-medium text-slate-900 text-sm">
                      {conseiller.prenom} {conseiller.nom}
                    </p>
                    <div className={`inline-flex items-center space-x-1 px-2 py-0.5 rounded-full text-xs font-medium ${getStatutColor(conseiller.statut)}`}>
                      {getStatutIcon(conseiller.statut)}
                      <span className="capitalize">{conseiller.statut.replace('_', ' ')}</span>
                    </div>
                  </div>
                </div>
              </label>
            ))}
          </div>
          
          {selectedConseillers.length > 0 && (
            <div className="mt-4 p-3 bg-purple-50 rounded-lg">
              <p className="text-sm text-purple-700">
                <span className="font-medium">{selectedConseillers.length}</span> conseiller(s) sélectionné(s) sur {conseillers.length}
              </p>
            </div>
          )}
        </div>

        {/* Statistiques globales */}
        <div className="bg-white rounded-xl shadow-lg p-6">
          <h2 className="text-lg font-semibold text-slate-900 mb-4">Vue d'Ensemble</h2>
          
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="bg-gradient-to-br from-emerald-500 to-green-600 text-white p-4 rounded-lg">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-emerald-100 text-sm">Disponible</p>
                  <p className="text-2xl font-bold">{totalStats.heures_disponible}h</p>
                  <p className="text-emerald-200 text-xs">{totalStats.pourcentage_disponible}%</p>
                </div>
                <CheckCircle className="w-8 h-8 text-emerald-200" />
              </div>
            </div>

            <div className="bg-gradient-to-br from-amber-500 to-orange-600 text-white p-4 rounded-lg">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-amber-100 text-sm">Avec Client</p>
                  <p className="text-2xl font-bold">{totalStats.heures_avec_client}h</p>
                  <p className="text-amber-200 text-xs">{totalStats.pourcentage_avec_client}%</p>
                </div>
                <Timer className="w-8 h-8 text-amber-200" />
              </div>
            </div>

            <div className="bg-gradient-to-br from-red-500 to-rose-600 text-white p-4 rounded-lg">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-red-100 text-sm">Indisponible</p>
                  <p className="text-2xl font-bold">{totalStats.heures_indisponible}h</p>
                  <p className="text-red-200 text-xs">{totalStats.pourcentage_indisponible}%</p>
                </div>
                <AlertCircle className="w-8 h-8 text-red-200" />
              </div>
            </div>

            <div className="bg-gradient-to-br from-slate-500 to-slate-600 text-white p-4 rounded-lg">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-slate-100 text-sm">Total</p>
                  <p className="text-2xl font-bold">{totalStats.total_heures}h</p>
                  <p className="text-slate-200 text-xs">{selectedConseillers.length > 0 ? selectedConseillers.length : conseillers.length} conseiller(s)</p>
                </div>
                <Clock className="w-8 h-8 text-slate-200" />
              </div>
            </div>
          </div>
        </div>

        {/* Détail par conseiller */}
        <div className="bg-white rounded-xl shadow-lg p-6">
          <h2 className="text-lg font-semibold text-slate-900 mb-6">Détail par Conseiller</h2>
          
          {stats.length === 0 ? (
            <div className="text-center py-8">
              <div className="bg-slate-100 p-3 rounded-full w-fit mx-auto mb-3">
                <Users className="w-6 h-6 text-slate-400" />
              </div>
              <p className="text-slate-600">Aucune donnée disponible pour la période sélectionnée</p>
            </div>
          ) : (
            <div className="space-y-4">
              {stats.map((stat) => {
                const conseiller = conseillers.find(c => c.id === stat.conseiller_id);
                if (!conseiller) return null;
                
                return (
                  <div key={stat.conseiller_id} className="border border-slate-200 rounded-lg p-4 hover:shadow-md transition-shadow">
                    <div className="flex items-center justify-between mb-4">
                      <div className="flex items-center space-x-3">
                        <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-indigo-600 rounded-full flex items-center justify-center">
                          <span className="text-white font-bold text-sm">
                            {getInitials(conseiller.prenom, conseiller.nom)}
                          </span>
                        </div>
                        <div>
                          <h3 className="font-semibold text-slate-900">{conseiller.prenom} {conseiller.nom}</h3>
                          <div className={`inline-flex items-center space-x-1 px-2 py-1 rounded-full text-xs font-medium ${getStatutColor(conseiller.statut)}`}>
                            {getStatutIcon(conseiller.statut)}
                            <span className="capitalize">{conseiller.statut.replace('_', ' ')}</span>
                          </div>
                        </div>
                      </div>
                      <div className="text-right">
                        <p className="text-sm text-slate-600">Total</p>
                        <p className="text-lg font-bold text-slate-900">{stat.total_heures}h</p>
                      </div>
                    </div>

                    {/* Barre de progression */}
                    <div className="mb-4">
                      <div className="flex items-center justify-between text-xs text-slate-600 mb-1">
                        <span>Répartition du temps</span>
                        <span>100%</span>
                      </div>
                      <div className="w-full bg-slate-200 rounded-full h-3 overflow-hidden">
                        <div className="h-full flex">
                          <div 
                            className="bg-emerald-500" 
                            style={{ width: `${stat.pourcentage_disponible}%` }}
                          ></div>
                          <div 
                            className="bg-amber-500" 
                            style={{ width: `${stat.pourcentage_avec_client}%` }}
                          ></div>
                          <div 
                            className="bg-red-500" 
                            style={{ width: `${stat.pourcentage_indisponible}%` }}
                          ></div>
                        </div>
                      </div>
                    </div>

                    {/* Détails des heures */}
                    <div className="grid grid-cols-3 gap-4 text-center">
                      <div className="bg-emerald-50 p-3 rounded-lg">
                        <p className="text-emerald-600 font-semibold">{stat.heures_disponible}h</p>
                        <p className="text-emerald-700 text-xs">Disponible ({stat.pourcentage_disponible}%)</p>
                      </div>
                      
                      <div className="bg-amber-50 p-3 rounded-lg">
                        <p className="text-amber-600 font-semibold">{stat.heures_avec_client}h</p>
                        <p className="text-amber-700 text-xs">Avec Client ({stat.pourcentage_avec_client}%)</p>
                      </div>
                      
                      <div className="bg-red-50 p-3 rounded-lg">
                        <p className="text-red-600 font-semibold">{stat.heures_indisponible}h</p>
                        <p className="text-red-700 text-xs">Indisponible ({stat.pourcentage_indisponible}%)</p>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>
    </Layout>
  );
}