import React, { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import { supabase, getConseillerByUrl, updateConseillerStatut } from '../lib/supabase';
import { CheckCircle, Clock, AlertCircle, Headphones, User } from 'lucide-react';
import { Conseiller } from '../types';

const ConseillerInterface = () => {
  const { conseillerUrl } = useParams<{ conseillerUrl: string }>();
  const [conseiller, setConseiller] = useState<Conseiller | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [isUpdating, setIsUpdating] = useState(false);

  useEffect(() => {
    if (conseillerUrl) {
      loadConseiller();
    }
  }, [conseillerUrl]);

  useEffect(() => {
    if (!conseiller) return;

    const channelName = `conseiller_${conseiller.id}_${Date.now()}`;
    const channel = supabase
      .channel(channelName)
      .on(
        'postgres_changes',
        {
          event: 'UPDATE',
          schema: 'public',
          table: 'conseillers',
          filter: `id=eq.${conseiller.id}`
        },
        (payload) => {
          if (payload.new && !isUpdating) {
            setConseiller(payload.new as Conseiller);
          }
        }
      )
      .subscribe();

    return () => {
      channel.unsubscribe();
    };
  }, [conseiller?.id]);

  const loadConseiller = async () => {
    try {
      setLoading(true);
      
      const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
      const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;
      
      const isSupabaseConfigured = supabaseUrl && 
        supabaseAnonKey && 
        supabaseUrl !== 'your_supabase_project_url' && 
        supabaseAnonKey !== 'your_supabase_anon_key' &&
        supabaseUrl.startsWith('https://') && 
        supabaseUrl.includes('.supabase.co');
      
      if (!isSupabaseConfigured) {
        setError('Supabase n\'est pas configuré. Veuillez configurer votre base de données.');
        setLoading(false);
        return;
      }
      
      const data = await getConseillerByUrl(conseillerUrl!);
      setConseiller(data);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const handleStatutChange = async (nouveauStatut: string) => {
    if (!conseiller) return;
    
    setIsUpdating(true);
    try {
      const updatedConseiller = await updateConseillerStatut(conseiller.id, nouveauStatut);
      setConseiller(updatedConseiller);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setIsUpdating(false);
    }
  };

  const getStatutConfig = (statut: string) => {
    switch (statut) {
      case 'disponible':
        return {
          color: 'bg-gradient-to-br from-emerald-500 to-green-600 text-white border-emerald-500 hover:from-emerald-600 hover:to-green-700 shadow-emerald-200',
          icon: <CheckCircle className="w-10 h-10" />,
          label: 'Disponible',
          bgColor: 'bg-emerald-50',
          iconColor: 'text-emerald-600'
        };
      case 'avec_client':
        return {
          color: 'bg-gradient-to-br from-amber-500 to-orange-600 text-white border-amber-500 hover:from-amber-600 hover:to-orange-700 shadow-amber-200',
          icon: <Clock className="w-10 h-10" />,
          label: 'Avec Client',
          bgColor: 'bg-amber-50',
          iconColor: 'text-amber-600'
        };
      case 'indisponible':
        return {
          color: 'bg-gradient-to-br from-red-500 to-rose-600 text-white border-red-500 hover:from-red-600 hover:to-rose-700 shadow-red-200',
          icon: <AlertCircle className="w-10 h-10" />,
          label: 'Indisponible',
          bgColor: 'bg-red-50',
          iconColor: 'text-red-600'
        };
      default:
        return {
          color: 'bg-gradient-to-br from-slate-400 to-slate-500 text-white border-slate-400 shadow-slate-200',
          icon: <Clock className="w-10 h-10" />,
          label: 'Inconnu',
          bgColor: 'bg-slate-50',
          iconColor: 'text-slate-600'
        };
    }
  };

  const getInitials = (prenom: string, nom: string) => {
    return `${prenom.charAt(0)}${nom.charAt(0)}`.toUpperCase();
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-100 flex items-center justify-center">
        <div className="bg-white/80 backdrop-blur-sm rounded-2xl shadow-xl p-12 text-center border border-white/20">
          <div className="relative">
            <div className="animate-spin rounded-full h-16 w-16 border-4 border-orange-200 border-t-orange-500 mx-auto mb-6"></div>
            <div className="absolute inset-0 rounded-full bg-orange-100 opacity-20 animate-pulse"></div>
          </div>
          <p className="text-slate-700 font-medium text-lg">Chargement de votre interface...</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-100 flex items-center justify-center">
        <div className="bg-white/90 backdrop-blur-sm rounded-2xl shadow-xl p-10 text-center max-w-md border border-white/20">
          <div className="bg-red-100 p-4 rounded-2xl w-fit mx-auto mb-6">
            <AlertCircle className="w-10 h-10 text-red-600" />
          </div>
          <h2 className="text-2xl font-bold text-slate-900 mb-3">Erreur de Connexion</h2>
          <p className="text-red-600 mb-6 leading-relaxed">{error}</p>
          <button
            onClick={loadConseiller}
            className="bg-gradient-to-r from-orange-500 to-amber-500 text-white px-6 py-3 rounded-xl hover:from-orange-600 hover:to-amber-600 transition-all duration-300 font-semibold shadow-lg hover:shadow-xl transform hover:-translate-y-0.5"
          >
            Réessayer
          </button>
        </div>
      </div>
    );
  }

  if (!conseiller) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-100 flex items-center justify-center">
        <div className="bg-white/90 backdrop-blur-sm rounded-2xl shadow-xl p-10 text-center border border-white/20">
          <div className="bg-slate-100 p-4 rounded-2xl w-fit mx-auto mb-6">
            <User className="w-10 h-10 text-slate-600" />
          </div>
          <h2 className="text-2xl font-bold text-slate-900 mb-3">Conseiller Introuvable</h2>
          <p className="text-slate-600 leading-relaxed">Aucun conseiller trouvé avec cette URL.</p>
        </div>
      </div>
    );
  }

  const currentStatutConfig = getStatutConfig(conseiller.statut);

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-100">
      {/* Header Moderne */}
      <header className="bg-white/80 backdrop-blur-md shadow-lg border-b border-white/20">
        <div className="max-w-4xl mx-auto px-6 py-8">
          <div className="text-center">
            {/* Logo et Titre Principal */}
            <div className="flex items-center justify-center space-x-4 mb-6">
              <div className="bg-gradient-to-br from-orange-500 to-amber-600 p-3 rounded-2xl shadow-lg">
                <Headphones className="w-8 h-8 text-white" />
              </div>
              <h1 className="text-3xl font-bold bg-gradient-to-r from-orange-600 to-amber-600 bg-clip-text text-transparent">
                KOM TRANSFER 2.0
              </h1>
            </div>
            
            {/* Séparateur Visuel */}
            <div className="w-24 h-1 bg-gradient-to-r from-orange-400 to-amber-400 rounded-full mx-auto mb-6"></div>
            
            {/* Profil Conseiller */}
            <div className="flex items-center justify-center space-x-4 mb-4">
              <div className="relative">
                <div className="w-16 h-16 bg-gradient-to-br from-blue-500 to-indigo-600 rounded-full flex items-center justify-center shadow-lg">
                  <span className="text-white font-bold text-xl">
                    {getInitials(conseiller.prenom, conseiller.nom)}
                  </span>
                </div>
                <div className="absolute -bottom-1 -right-1 w-6 h-6 bg-emerald-500 rounded-full border-3 border-white flex items-center justify-center">
                  <div className="w-2 h-2 bg-white rounded-full animate-pulse"></div>
                </div>
              </div>
              <div className="text-left">
                <h2 className="text-2xl font-bold text-slate-900">
                  {conseiller.prenom} {conseiller.nom}
                </h2>
                <p className="text-slate-600 font-medium">Conseiller Certifié</p>
              </div>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-4xl mx-auto px-6 py-12 space-y-10">
        {/* Statut Actuel */}
        <div className="bg-white/90 backdrop-blur-sm rounded-3xl shadow-xl p-10 text-center border border-white/20">
          <h3 className="text-2xl font-bold text-slate-900 mb-8">Mon Statut Actuel</h3>
          <div className={`inline-flex flex-col items-center space-y-4 px-12 py-8 rounded-2xl border-2 transition-all duration-500 ${currentStatutConfig.color} shadow-2xl hover:shadow-3xl transform hover:-translate-y-1`}>
            <div className="relative">
              {currentStatutConfig.icon}
              <div className="absolute inset-0 bg-white/20 rounded-full animate-ping"></div>
            </div>
            <span className="text-2xl font-bold tracking-wide">{currentStatutConfig.label}</span>
          </div>
        </div>

        {/* Séparateur Décoratif */}
        <div className="flex items-center justify-center">
          <div className="flex-1 h-px bg-gradient-to-r from-transparent via-slate-300 to-transparent"></div>
          <div className="px-6">
            <div className="w-3 h-3 bg-orange-400 rounded-full"></div>
          </div>
          <div className="flex-1 h-px bg-gradient-to-r from-transparent via-slate-300 to-transparent"></div>
        </div>

        {/* Changer de Statut */}
        <div className="bg-white/90 backdrop-blur-sm rounded-3xl shadow-xl p-10 border border-white/20">
          <h3 className="text-2xl font-bold text-slate-900 mb-8 text-center">Modifier Mon Statut</h3>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {['disponible', 'avec_client', 'indisponible'].map((statut) => {
              const config = getStatutConfig(statut);
              const isActive = conseiller.statut === statut;
              
              return (
                <button
                  key={statut}
                  onClick={() => handleStatutChange(statut)}
                  disabled={isUpdating || isActive}
                  className={`group relative p-8 rounded-2xl border-2 transition-all duration-300 flex flex-col items-center space-y-4 overflow-hidden ${
                    isActive
                      ? `${config.color} scale-105 shadow-2xl`
                      : `border-slate-200 hover:border-orange-300 hover:bg-gradient-to-br hover:from-orange-50 hover:to-amber-50 text-slate-700 hover:shadow-xl hover:-translate-y-1 ${config.bgColor}`
                  } ${
                    isUpdating ? 'opacity-50 cursor-not-allowed' : 'cursor-pointer'
                  }`}
                >
                  {/* Effet de fond animé */}
                  <div className="absolute inset-0 bg-gradient-to-br from-white/10 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                  
                  <div className={`relative z-10 p-3 rounded-2xl transition-all duration-300 ${
                    isActive ? 'bg-white/20' : `${config.bgColor} group-hover:scale-110`
                  }`}>
                    <div className={isActive ? 'text-white' : config.iconColor}>
                      {config.icon}
                    </div>
                  </div>
                  
                  <div className="relative z-10 text-center">
                    <span className="font-bold text-lg tracking-wide">
                      {config.label}
                    </span>
                    {isActive && (
                      <div className="mt-2">
                        <div className="inline-flex items-center space-x-1 bg-white/20 px-3 py-1 rounded-full">
                          <div className="w-2 h-2 bg-white rounded-full animate-pulse"></div>
                          <span className="text-xs font-medium">Actuel</span>
                        </div>
                      </div>
                    )}
                  </div>
                  
                  {/* Effet de brillance au hover */}
                  <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/10 to-transparent -skew-x-12 -translate-x-full group-hover:translate-x-full transition-transform duration-700"></div>
                </button>
              );
            })}
          </div>
          
          {isUpdating && (
            <div className="mt-8 text-center">
              <div className="inline-flex items-center space-x-3 bg-orange-50 text-orange-700 px-6 py-3 rounded-full border border-orange-200">
                <div className="relative">
                  <div className="animate-spin rounded-full h-5 w-5 border-2 border-orange-300 border-t-orange-600"></div>
                </div>
                <span className="font-medium">Mise à jour en cours...</span>
              </div>
            </div>
          )}
        </div>

        {/* Informations Supplémentaires */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="bg-white/70 backdrop-blur-sm rounded-2xl shadow-lg p-6 border border-white/20 hover:shadow-xl transition-all duration-300">
            <h4 className="text-lg font-bold text-slate-900 mb-3 flex items-center space-x-2">
              <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
              <span>Contact</span>
            </h4>
            <div className="space-y-2 text-slate-600">
              <p className="flex items-center space-x-2">
                <span className="font-medium">Email:</span>
                <span>{conseiller.email}</span>
              </p>
              <p className="flex items-center space-x-2">
                <span className="font-medium">Téléphone:</span>
                <span>{conseiller.telephone}</span>
              </p>
            </div>
          </div>
          
          <div className="bg-white/70 backdrop-blur-sm rounded-2xl shadow-lg p-6 border border-white/20 hover:shadow-xl transition-all duration-300">
            <h4 className="text-lg font-bold text-slate-900 mb-3 flex items-center space-x-2">
              <div className="w-2 h-2 bg-orange-500 rounded-full"></div>
              <span>Préférences</span>
            </h4>
            <div className="space-y-2 text-slate-600">
              <p className="flex items-center space-x-2">
                <span className="font-medium">Communication:</span>
                <span className="capitalize">{conseiller.methode_comm}</span>
              </p>
              <p className="flex items-center space-x-2">
                <span className="font-medium">Transferts demandés:</span>
                <span>{conseiller.nb_transferts_demandes}</span>
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ConseillerInterface;