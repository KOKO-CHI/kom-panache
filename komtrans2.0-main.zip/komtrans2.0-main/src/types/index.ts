export interface Conseiller {
  id: string;
  nom: string;
  prenom: string;
  telephone: string;
  email: string;
  nb_transferts_demandes: number;
  methode_comm: 'email' | 'teams';
  assurance_vie: boolean;
  assurance_hypothecaire: boolean;
  assurance_invalidite: boolean;
  notes?: string;
  statut: 'disponible' | 'indisponible' | 'avec_client';
  url_unique: string;
  created_at: string;
  transferts?: Transfert[];
}

export interface Transfert {
  id: string;
  conseiller_id: string;
  nom_client: string;
  date_transfert: string;
  heure_transfert: string;
  type_assurance?: string;
  created_at: string;
}

export interface ConseillerStats {
  transferts_realises: number;
  transferts_aujourd_hui: number;
  transferts_semaine: number;
  transferts_mois: number;
}