/*
  # KOM TRANSFER - Schema de Base de Données

  1. Nouvelles Tables
    - `conseillers`
      - `id` (uuid, clé primaire)
      - `nom` (text, requis)
      - `prenom` (text, requis)  
      - `telephone` (text, requis)
      - `email` (text, requis, unique)
      - `nb_transferts_demandes` (integer, défaut 10)
      - `methode_comm` (text, 'email' ou 'teams')
      - `assurance_vie` (boolean, défaut false)
      - `assurance_hypothecaire` (boolean, défaut false)
      - `assurance_invalidite` (boolean, défaut false)
      - `notes` (text, optionnel)
      - `statut` (text, 'disponible', 'indisponible', 'avec_client')
      - `url_unique` (text, unique)
      - `created_at` (timestamptz, défaut now())

    - `transferts`
      - `id` (uuid, clé primaire)
      - `conseiller_id` (uuid, référence vers conseillers)
      - `nom_client` (text, requis)
      - `date_transfert` (date, défaut aujourd'hui)
      - `heure_transfert` (time, défaut maintenant)
      - `type_assurance` (text, optionnel)
      - `created_at` (timestamptz, défaut now())

  2. Sécurité
    - Activer RLS sur les deux tables
    - Politique pour permettre la lecture/écriture anonyme (pour simplifier l'accès)
    - En production, implémenter une authentification plus robuste
*/

-- Table des conseillers
CREATE TABLE IF NOT EXISTS conseillers (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  nom text NOT NULL,
  prenom text NOT NULL,
  telephone text NOT NULL,
  email text NOT NULL UNIQUE,
  nb_transferts_demandes integer DEFAULT 10,
  methode_comm text CHECK (methode_comm IN ('email', 'teams')) DEFAULT 'email',
  assurance_vie boolean DEFAULT false,
  assurance_hypothecaire boolean DEFAULT false,
  assurance_invalidite boolean DEFAULT false,
  notes text,
  statut text CHECK (statut IN ('disponible', 'indisponible', 'avec_client')) DEFAULT 'disponible',
  url_unique text NOT NULL UNIQUE,
  created_at timestamptz DEFAULT now()
);

-- Table des transferts
CREATE TABLE IF NOT EXISTS transferts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  conseiller_id uuid NOT NULL REFERENCES conseillers(id) ON DELETE CASCADE,
  nom_client text NOT NULL,
  date_transfert date DEFAULT CURRENT_DATE,
  heure_transfert time DEFAULT CURRENT_TIME,
  type_assurance text,
  created_at timestamptz DEFAULT now()
);

-- Index pour les performances
CREATE INDEX IF NOT EXISTS idx_conseillers_url_unique ON conseillers(url_unique);
CREATE INDEX IF NOT EXISTS idx_conseillers_statut ON conseillers(statut);
CREATE INDEX IF NOT EXISTS idx_transferts_conseiller_id ON transferts(conseiller_id);
CREATE INDEX IF NOT EXISTS idx_transferts_date ON transferts(date_transfert);

-- Activer RLS
ALTER TABLE conseillers ENABLE ROW LEVEL SECURITY;
ALTER TABLE transferts ENABLE ROW LEVEL SECURITY;

-- Politiques RLS (accès anonyme pour simplifier - à sécuriser en production)
CREATE POLICY "Public access to conseillers"
  ON conseillers
  FOR ALL
  TO anon
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Public access to transferts"
  ON transferts
  FOR ALL
  TO anon
  USING (true)
  WITH CHECK (true);

-- Fonction pour nettoyer l'URL unique
CREATE OR REPLACE FUNCTION clean_url_unique()
RETURNS TRIGGER AS $$
BEGIN
  NEW.url_unique = lower(replace(NEW.url_unique, ' ', ''));
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Trigger pour nettoyer l'URL unique
DROP TRIGGER IF EXISTS clean_url_unique_trigger ON conseillers;
CREATE TRIGGER clean_url_unique_trigger
  BEFORE INSERT OR UPDATE ON conseillers
  FOR EACH ROW
  EXECUTE FUNCTION clean_url_unique();