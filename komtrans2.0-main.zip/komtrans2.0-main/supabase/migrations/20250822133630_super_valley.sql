/*
  # Système de tracking des changements de statut

  1. Nouvelles Tables
    - `status_history`
      - `id` (uuid, primary key)
      - `conseiller_id` (uuid, foreign key)
      - `ancien_statut` (text, nullable pour le premier enregistrement)
      - `nouveau_statut` (text, not null)
      - `timestamp_debut` (timestamptz, default now())
      - `timestamp_fin` (timestamptz, nullable)
      - `duree_minutes` (integer, nullable)
      - `created_at` (timestamptz, default now())

  2. Fonctions
    - `handle_status_change()` - Trigger function pour gérer les changements
    - `clean_url_unique()` - Fonction pour nettoyer les URLs

  3. Triggers
    - Trigger sur UPDATE de conseillers pour tracker les changements

  4. Sécurité
    - Enable RLS sur status_history
    - Politique d'accès public pour la démo

  5. Index
    - Index sur conseiller_id, timestamp_debut, timestamp_fin, nouveau_statut
*/

-- Créer la table d'historique des statuts
CREATE TABLE IF NOT EXISTS status_history (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  conseiller_id uuid NOT NULL REFERENCES conseillers(id) ON DELETE CASCADE,
  ancien_statut text CHECK (ancien_statut IS NULL OR ancien_statut IN ('disponible', 'indisponible', 'avec_client')),
  nouveau_statut text NOT NULL CHECK (nouveau_statut IN ('disponible', 'indisponible', 'avec_client')),
  timestamp_debut timestamptz DEFAULT now() NOT NULL,
  timestamp_fin timestamptz,
  duree_minutes integer,
  created_at timestamptz DEFAULT now()
);

-- Activer RLS
ALTER TABLE status_history ENABLE ROW LEVEL SECURITY;

-- Politique d'accès public pour la démo
CREATE POLICY "Public access to status_history"
  ON status_history
  FOR ALL
  TO anon
  USING (true)
  WITH CHECK (true);

-- Index pour les performances
CREATE INDEX IF NOT EXISTS idx_status_history_conseiller_id ON status_history(conseiller_id);
CREATE INDEX IF NOT EXISTS idx_status_history_timestamp_debut ON status_history(timestamp_debut);
CREATE INDEX IF NOT EXISTS idx_status_history_timestamp_fin ON status_history(timestamp_fin);
CREATE INDEX IF NOT EXISTS idx_status_history_nouveau_statut ON status_history(nouveau_statut);

-- Fonction pour gérer les changements de statut
CREATE OR REPLACE FUNCTION handle_status_change()
RETURNS TRIGGER AS $$
BEGIN
  -- Si le statut a changé
  IF OLD.statut IS DISTINCT FROM NEW.statut THEN
    -- Fermer l'ancien enregistrement s'il existe
    UPDATE status_history 
    SET 
      timestamp_fin = now(),
      duree_minutes = EXTRACT(EPOCH FROM (now() - timestamp_debut)) / 60
    WHERE conseiller_id = NEW.id 
      AND timestamp_fin IS NULL;
    
    -- Créer un nouvel enregistrement pour le nouveau statut
    INSERT INTO status_history (
      conseiller_id,
      ancien_statut,
      nouveau_statut,
      timestamp_debut
    ) VALUES (
      NEW.id,
      OLD.statut,
      NEW.statut,
      now()
    );
  END IF;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Fonction pour nettoyer les URLs (si elle n'existe pas déjà)
CREATE OR REPLACE FUNCTION clean_url_unique()
RETURNS TRIGGER AS $$
BEGIN
  -- Nettoyer l'URL en supprimant les espaces et caractères spéciaux
  NEW.url_unique = lower(regexp_replace(NEW.url_unique, '[^a-zA-Z0-9]', '', 'g'));
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Créer le trigger pour les changements de statut
DROP TRIGGER IF EXISTS status_change_trigger ON conseillers;
CREATE TRIGGER status_change_trigger
  AFTER UPDATE ON conseillers
  FOR EACH ROW
  EXECUTE FUNCTION handle_status_change();

-- Créer le trigger pour nettoyer les URLs (si pas déjà existant)
DROP TRIGGER IF EXISTS clean_url_unique_trigger ON conseillers;
CREATE TRIGGER clean_url_unique_trigger
  BEFORE INSERT OR UPDATE ON conseillers
  FOR EACH ROW
  EXECUTE FUNCTION clean_url_unique();

-- Initialiser l'historique pour les conseillers existants
DO $$
DECLARE
  conseiller_record RECORD;
BEGIN
  FOR conseiller_record IN 
    SELECT id, statut FROM conseillers 
  LOOP
    -- Vérifier s'il n'y a pas déjà d'historique pour ce conseiller
    IF NOT EXISTS (
      SELECT 1 FROM status_history 
      WHERE conseiller_id = conseiller_record.id
    ) THEN
      -- Créer un enregistrement initial (comme s'il avait ce statut depuis 1h)
      INSERT INTO status_history (
        conseiller_id,
        ancien_statut,
        nouveau_statut,
        timestamp_debut
      ) VALUES (
        conseiller_record.id,
        NULL, -- Pas d'ancien statut pour l'initialisation
        conseiller_record.statut,
        now() - interval '1 hour' -- Simule qu'il a ce statut depuis 1h
      );
    END IF;
  END LOOP;
END $$;