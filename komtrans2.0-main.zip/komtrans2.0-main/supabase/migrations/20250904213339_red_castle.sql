/*
  # Create chat_messages table for real-time messaging

  1. New Tables
    - `chat_messages`
      - `id` (uuid, primary key)
      - `room_id` (text, identifies the chat room/conversation)
      - `sender_type` (text, 'user' or 'conseiller')
      - `content` (text, message content)
      - `conseiller_id` (uuid, optional reference to conseillers table)
      - `created_at` (timestamp)

  2. Security
    - Enable RLS on `chat_messages` table
    - Add policy for public access to allow anonymous users to read and write messages

  3. Indexes
    - Add index on room_id for efficient message retrieval
    - Add index on created_at for chronological ordering
*/

CREATE TABLE IF NOT EXISTS chat_messages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  room_id text NOT NULL,
  sender_type text NOT NULL CHECK (sender_type IN ('user', 'conseiller')),
  content text NOT NULL,
  conseiller_id uuid REFERENCES conseillers(id) ON DELETE SET NULL,
  created_at timestamptz DEFAULT now()
);

-- Add indexes for better performance
CREATE INDEX IF NOT EXISTS idx_chat_messages_room_id ON chat_messages(room_id);
CREATE INDEX IF NOT EXISTS idx_chat_messages_created_at ON chat_messages(created_at);
CREATE INDEX IF NOT EXISTS idx_chat_messages_conseiller_id ON chat_messages(conseiller_id);

-- Enable Row Level Security
ALTER TABLE chat_messages ENABLE ROW LEVEL SECURITY;

-- Create policy for public access (allows anonymous users to read and write messages)
CREATE POLICY "Public access to chat_messages"
  ON chat_messages
  FOR ALL
  TO anon
  USING (true)
  WITH CHECK (true);