/*
  # Nettoyer les logs WIZZ des notes

  1. Modifications
    - Nettoie toutes les notes contenant des logs WIZZ
    - Supprime les entrées "WIZZ! HH:MM:SS -" des notes
    - Remet les notes à NULL si elles ne contiennent que des logs WIZZ

  2. Sécurité
    - Opération de nettoyage sécurisée
    - Préserve les vraies notes utilisateur
*/

-- Nettoyer les logs WIZZ des notes
UPDATE conseillers 
SET notes = CASE 
  -- Si les notes ne contiennent que des logs WIZZ, les mettre à NULL
  WHEN TRIM(REGEXP_REPLACE(notes, 'WIZZ! \d{2}:\d{2}:\d{2} - ', '', 'g')) = '' THEN NULL
  -- Sinon, supprimer seulement les logs WIZZ et garder le reste
  ELSE TRIM(REGEXP_REPLACE(notes, 'WIZZ! \d{2}:\d{2}:\d{2} - ', '', 'g'))
END
WHERE notes IS NOT NULL 
  AND notes LIKE '%WIZZ!%';