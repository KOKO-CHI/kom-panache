/*
  # Système de tracking des changements de statut

  1. Nouvelle Table
    - `status_history`
      - `id` (uuid, primary key)
      - `conseiller_id` (uuid, foreign key vers conseillers)
      - `ancien_statut` (text, statut précédent)
      - `nouveau_statut` (text, nouveau statut)
      - `timestamp_debut` (timestamptz, début de la période)
      - `timestamp_fin` (timestamptz, fin de la période, null si en cours)
      - `duree_minutes` (integer, durée calculée en minutes)
      - `created_at` (timestamptz)

  2. Fonction de calcul automatique
    - Calcule automatiquement la durée quand un statut change
    - Met à jour l'enregistrement précédent avec timestamp_fin

  3. Trigger automatique
    - Se déclenche à chaque UPDATE du statut d'un conseiller
    - Crée automatiquement les enregistrements d'historique

  4. Sécurité
    - RLS activé sur la table
    - Politique d'accès public pour la démo
*/

-- Créer la table d'historique des statuts
CREATE TABLE IF NOT EXISTS status_history (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  conseiller_id uuid NOT NULL REFERENCES conseillers(id) ON DELETE CASCADE,
  ancien_statut text,
  nouveau_statut text NOT NULL,
  timestamp_debut timestamptz NOT NULL DEFAULT now(),
  timestamp_fin timestamptz,
  duree_minutes integer,
  created_at timestamptz DEFAULT now(),
  
  -- Contraintes
  CONSTRAINT status_history_statut_check 
    CHECK (nouveau_statut IN ('disponible', 'indisponible', 'avec_client')),
  CONSTRAINT status_history_ancien_statut_check 
    CHECK (ancien_statut IS NULL OR ancien_statut IN ('disponible', 'indisponible', 'avec_client'))
);

-- Index pour les performances
CREATE INDEX IF NOT EXISTS idx_status_history_conseiller_id ON status_history(conseiller_id);
CREATE INDEX IF NOT EXISTS idx_status_history_timestamp_debut ON status_history(timestamp_debut);
CREATE INDEX IF NOT EXISTS idx_status_history_timestamp_fin ON status_history(timestamp_fin);
CREATE INDEX IF NOT EXISTS idx_status_history_nouveau_statut ON status_history(nouveau_statut);

-- Activer RLS
ALTER TABLE status_history ENABLE ROW LEVEL SECURITY;

-- Politique d'accès public pour la démo
CREATE POLICY "Public access to status_history"
  ON status_history
  FOR ALL
  TO anon
  USING (true)
  WITH CHECK (true);

-- Fonction pour gérer les changements de statut
CREATE OR REPLACE FUNCTION handle_status_change()
RETURNS TRIGGER AS $$
BEGIN
  -- Si le statut a changé
  IF OLD.statut IS DISTINCT FROM NEW.statut THEN
    
    -- Fermer l'enregistrement précédent (s'il existe)
    UPDATE status_history 
    SET 
      timestamp_fin = now(),
      duree_minutes = EXTRACT(EPOCH FROM (now() - timestamp_debut)) / 60
    WHERE 
      conseiller_id = NEW.id 
      AND timestamp_fin IS NULL;
    
    -- Créer un nouvel enregistrement pour le nouveau statut
    INSERT INTO status_history (
      conseiller_id,
      ancien_statut,
      nouveau_statut,
      timestamp_debut
    ) VALUES (
      NEW.id,
      OLD.statut,
      NEW.statut,
      now()
    );
    
  END IF;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Créer le trigger
DROP TRIGGER IF EXISTS status_change_trigger ON conseillers;
CREATE TRIGGER status_change_trigger
  AFTER UPDATE ON conseillers
  FOR EACH ROW
  EXECUTE FUNCTION handle_status_change();

-- Initialiser l'historique pour les conseillers existants
INSERT INTO status_history (conseiller_id, nouveau_statut, timestamp_debut)
SELECT id, statut, created_at
FROM conseillers
WHERE NOT EXISTS (
  SELECT 1 FROM status_history WHERE conseiller_id = conseillers.id
);