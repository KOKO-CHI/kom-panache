import { createClient } from 'npm:@supabase/supabase-js@2.45.0'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
}

Deno.serve(async (req: Request) => {
  console.log('🚀 === TWILIO CALL ROUTER DÉMARRÉ ===')
  console.log(`📞 Méthode: ${req.method}`)
  console.log(`🌐 URL: ${req.url}`)
  console.log(`📅 Timestamp: ${new Date().toISOString()}`)
  
  // Gérer les requêtes OPTIONS pour CORS
  if (req.method === 'OPTIONS') {
    console.log('✅ Requête OPTIONS - Retour CORS headers')
    return new Response('ok', { headers: corsHeaders })
  }

  try {
    // Log des headers de la requête Twilio
    console.log('📋 Headers de la requête:')
    for (const [key, value] of req.headers.entries()) {
      console.log(`  ${key}: ${value}`)
    }

    // Lire le body de la requête Twilio
    let body = ''
    let twilioParams = new URLSearchParams()
    
    try {
      body = await req.text()
      console.log('📝 Body de la requête Twilio:', body)
      
      // Parser les paramètres Twilio (format form-urlencoded)
      if (body) {
        twilioParams = new URLSearchParams(body)
        console.log('📋 Paramètres Twilio parsés:')
        for (const [key, value] of twilioParams.entries()) {
          console.log(`  ${key}: ${value}`)
        }
      }
    } catch (e) {
      console.log('⚠️ Impossible de lire le body:', e.message)
    }

    // Vérifier les variables d'environnement
    const supabaseUrl = Deno.env.get('SUPABASE_URL')
    const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')
    const twilioAccountSid = Deno.env.get('TWILIO_ACCOUNT_SID')
    const twilioAuthToken = Deno.env.get('TWILIO_AUTH_TOKEN')
    const twilioPhoneNumber = Deno.env.get('TWILIO_PHONE_NUMBER')
    
    console.log('🔍 === VÉRIFICATION ENVIRONNEMENT ===')
    console.log(`SUPABASE_URL présent: ${!!supabaseUrl}`)
    console.log(`SUPABASE_SERVICE_ROLE_KEY présent: ${!!supabaseServiceKey}`)
    console.log(`TWILIO_ACCOUNT_SID présent: ${!!twilioAccountSid}`)
    console.log(`TWILIO_AUTH_TOKEN présent: ${!!twilioAuthToken}`)
    console.log(`TWILIO_PHONE_NUMBER présent: ${!!twilioPhoneNumber}`)
    
    if (supabaseUrl) {
      console.log(`SUPABASE_URL: ${supabaseUrl.substring(0, 30)}...`)
    }
    
    if (twilioPhoneNumber) {
      console.log(`TWILIO_PHONE_NUMBER: ${twilioPhoneNumber}`)
    }
    
    if (!supabaseUrl || !supabaseServiceKey) {
      console.error('❌ Variables d\'environnement Supabase manquantes')
      // Retourner un TwiML de fallback même en cas d'erreur de config
      const fallbackTwiml = `<?xml version="1.0" encoding="UTF-8"?>
<Response>
  <Say voice="alice" language="fr-FR">
    Bonjour et merci d'avoir appelé KOM Transfer. 
    Nous rencontrons actuellement un problème de configuration. 
    Veuillez rappeler dans quelques minutes.
  </Say>
</Response>`
      
      return new Response(fallbackTwiml, {
        status: 200,
        headers: {
          ...corsHeaders,
          'Content-Type': 'text/xml; charset=utf-8',
        },
      })
    }

    // Initialiser le client Supabase avec la clé de service (pas d'auth requise)
    console.log('🔧 Initialisation du client Supabase...')
    const supabase = createClient(supabaseUrl, supabaseServiceKey, {
      auth: {
        autoRefreshToken: false,
        persistSession: false
      }
    })

    // Test de connexion Supabase
    console.log('🔗 Test de connexion à Supabase...')
    const { data: testData, error: testError } = await supabase
      .from('conseillers')
      .select('count')
      .limit(1)

    if (testError) {
      console.error('❌ Erreur de connexion Supabase:', testError)
      throw new Error(`Connexion Supabase échouée: ${testError.message}`)
    }
    
    console.log('✅ Connexion Supabase réussie')

    // Récupérer les conseillers disponibles
    console.log('👥 === RÉCUPÉRATION DES CONSEILLERS ===')
    const { data: conseillers, error } = await supabase
      .from('conseillers')
      .select('id, nom, prenom, telephone, statut')
      .eq('statut', 'disponible')
      .order('created_at', { ascending: true })

    if (error) {
      console.error('❌ Erreur lors de la récupération des conseillers:', error)
      throw new Error(`Erreur base de données: ${error.message}`)
    }

    console.log(`📊 ${conseillers?.length || 0} conseillers trouvés`)
    
    // Afficher les détails des conseillers (masquer les numéros complets)
    if (conseillers && conseillers.length > 0) {
      conseillers.forEach((conseiller, index) => {
        const telMasque = conseiller.telephone ? 
          conseiller.telephone.substring(0, 3) + '***' + conseiller.telephone.slice(-4) : 
          'N/A'
        console.log(`👤 ${index + 1}. ${conseiller.prenom} ${conseiller.nom} - Tel: ${telMasque} - Statut: ${conseiller.statut}`)
      })
    } else {
      console.log('⚠️ Aucun conseiller avec statut "disponible" trouvé')
    }

    // Générer la réponse TwiML
    console.log('📝 === GÉNÉRATION TWIML ===')
    let twimlResponse = ''

    if (!conseillers || conseillers.length === 0) {
      console.log('⚠️ Aucun conseiller disponible - Message d\'indisponibilité')
      
      twimlResponse = `<?xml version="1.0" encoding="UTF-8"?>
<Response>
  <Say voice="alice" language="fr-FR">
    Bonjour et merci d'avoir appelé KOM Transfer. 
    Malheureusement, tous nos conseillers sont actuellement occupés. 
    Veuillez laisser un message après le signal sonore et nous vous rappellerons dans les plus brefs délais.
  </Say>
  <Beep />
  <Record maxLength="120" transcribe="false" playBeep="false" />
  <Say voice="alice" language="fr-FR">
    Merci pour votre message. Nous vous contacterons très prochainement. Au revoir.
  </Say>
</Response>`
    } else {
      console.log('✅ Conseillers disponibles - Préparation des appels')
      
      // Filtrer et formater les numéros valides
      const numerosValides = []
      
      for (const conseiller of conseillers) {
        if (!conseiller.telephone || conseiller.telephone.trim() === '') {
          console.log(`⚠️ ${conseiller.prenom} ${conseiller.nom}: Pas de numéro de téléphone`)
          continue
        }
        
        // Nettoyer le numéro
        let numero = conseiller.telephone.replace(/[^\d+]/g, '')
        
        // Formater selon les standards nord-américains
        if (numero.startsWith('+1')) {
          // Déjà au bon format
        } else if (numero.startsWith('1') && numero.length === 11) {
          numero = '+' + numero
        } else if (numero.length === 10) {
          numero = '+1' + numero
        } else if (numero.startsWith('+') && numero.length === 12) {
          // Format +1XXXXXXXXXX déjà correct
        } else {
          console.log(`⚠️ ${conseiller.prenom} ${conseiller.nom}: Numéro invalide (${conseiller.telephone})`)
          continue
        }
        
        // Vérifier que le numéro final est valide
        if (numero.length >= 12 && numero.startsWith('+1')) {
          numerosValides.push({
            numero: numero,
            nom: `${conseiller.prenom} ${conseiller.nom}`
          })
          console.log(`✅ ${conseiller.prenom} ${conseiller.nom}: ${numero}`)
        } else {
          console.log(`❌ ${conseiller.prenom} ${conseiller.nom}: Format final invalide (${numero})`)
        }
      }

      console.log(`📞 ${numerosValides.length} numéros valides à appeler`)

      if (numerosValides.length === 0) {
        console.log('❌ Aucun numéro valide - Message d\'erreur technique')
        twimlResponse = `<?xml version="1.0" encoding="UTF-8"?>
<Response>
  <Say voice="alice" language="fr-FR">
    Bonjour et merci d'avoir appelé KOM Transfer. 
    Nous rencontrons actuellement un problème technique avec notre système de routage. 
    Veuillez rappeler dans quelques minutes ou laisser un message après le signal sonore.
  </Say>
  <Beep />
  <Record maxLength="120" transcribe="false" playBeep="false" />
  <Say voice="alice" language="fr-FR">Merci pour votre message. Au revoir.</Say>
</Response>`
      } else {
        // Créer la liste des numéros pour TwiML
        const numerosTwiML = numerosValides
          .map(item => `    <Number>${item.numero}</Number>`)
          .join('\n')

        console.log('📋 TwiML Numbers à générer:')
        numerosValides.forEach(item => {
          console.log(`  - ${item.nom}: ${item.numero}`)
        })

        twimlResponse = `<?xml version="1.0" encoding="UTF-8"?>
<Response>
  <Say voice="alice" language="fr-FR">
    Bonjour et bienvenue chez KOM Transfer. 
    Nous vous mettons en relation avec un de nos conseillers disponibles. 
    Veuillez patienter quelques instants.
  </Say>
  <Dial timeout="30" callerId="${twilioPhoneNumber || '+14388058252'}" record="record-from-ringing">
${numerosTwiML}
  </Dial>
  <Say voice="alice" language="fr-FR">
    Nous sommes désolés, aucun conseiller n'a pu répondre à votre appel en ce moment. 
    Veuillez laisser un message détaillé après le signal sonore et nous vous rappellerons rapidement.
  </Say>
  <Beep />
  <Record maxLength="120" transcribe="false" playBeep="false" />
  <Say voice="alice" language="fr-FR">
    Merci pour votre message. Nous vous contacterons dans les plus brefs délais. Au revoir.
  </Say>
</Response>`
      }
    }

    console.log('📤 === ENVOI RÉPONSE TWIML ===')
    console.log('Longueur TwiML:', twimlResponse.length)
    console.log('TwiML généré:')
    console.log(twimlResponse)

    // Retourner la réponse TwiML
    return new Response(twimlResponse, {
      status: 200,
      headers: {
        ...corsHeaders,
        'Content-Type': 'text/xml; charset=utf-8',
      },
    })

  } catch (error) {
    console.error('💥 === ERREUR CRITIQUE ===')
    console.error('Message:', error.message)
    console.error('Stack:', error.stack)
    console.error('Type:', error.constructor.name)
    
    // En cas d'erreur, TOUJOURS retourner un TwiML valide
    const fallbackTwiml = `<?xml version="1.0" encoding="UTF-8"?>
<Response>
  <Say voice="alice" language="fr-FR">
    Bonjour et merci d'avoir appelé KOM Transfer. 
    Nous rencontrons actuellement un problème technique temporaire. 
    Veuillez rappeler dans quelques minutes ou laisser un message après le signal sonore.
  </Say>
  <Beep />
  <Record maxLength="120" transcribe="false" playBeep="false" />
  <Say voice="alice" language="fr-FR">
    Merci pour votre message. Nous traiterons votre demande dès que possible. Au revoir.
  </Say>
</Response>`

    console.log('🔄 Envoi TwiML de fallback')
    console.log(fallbackTwiml)
    
    return new Response(fallbackTwiml, {
      status: 200, // TOUJOURS 200 pour Twilio
      headers: {
        ...corsHeaders,
        'Content-Type': 'text/xml; charset=utf-8',
      },
    })
  }
})