# Twilio Call Router - Edge Function

Cette fonction Supabase Edge sert de webhook pour Twilio et route automatiquement les appels entrants vers les conseillers disponibles.

## Configuration requise

### 1. Variables d'environnement Supabase

Ajoutez ces secrets dans votre projet Supabase (Project Settings > Secrets) :

```
TWILIO_ACCOUNT_SID=votre_account_sid_twilio
TWILIO_AUTH_TOKEN=votre_auth_token_twilio  
TWILIO_PHONE_NUMBER=votre_numero_twilio_principal
```

### 2. Configuration Twilio

1. Connectez-vous à votre console Twilio
2. Allez dans Phone Numbers > Manage > Active numbers
3. Cliquez sur votre numéro de téléphone
4. Dans la section "Voice Configuration" :
   - Webhook : `https://votre-projet-id.supabase.co/functions/v1/twilio-call-router`
   - HTTP Method : POST

## Fonctionnement

1. **Appel entrant** : Un client appelle votre numéro Twilio
2. **Webhook déclenché** : Twilio envoie une requête POST à cette fonction
3. **Vérification des conseillers** : La fonction interroge Supabase pour trouver les conseillers avec `statut = 'disponible'`
4. **Routage de l'appel** :
   - Si des conseillers sont disponibles : Twilio les appelle simultanément
   - Si aucun conseiller disponible : Message d'indisponibilité + messagerie vocale

## Réponse TwiML

La fonction génère du XML TwiML que Twilio utilise pour contrôler l'appel :

- `<Say>` : Messages vocaux en français
- `<Dial>` : Instructions pour appeler les conseillers
- `<Number>` : Numéros de téléphone des conseillers disponibles
- `<Record>` : Enregistrement de message vocal si personne n'est disponible

## Test et débogage

Pour tester la fonction :

1. Vérifiez que vos conseillers ont le statut 'disponible' dans la base de données
2. Appelez votre numéro Twilio
3. Consultez les logs dans Supabase Dashboard > Edge Functions

## Personnalisation

Vous pouvez modifier :
- Les messages vocaux dans les balises `<Say>`
- La durée d'attente avec `timeout="30"`
- Le comportement de la messagerie vocale avec `<Record>`