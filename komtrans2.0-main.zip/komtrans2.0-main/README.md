komtrans2.0
